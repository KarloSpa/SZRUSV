package tipke;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;


import strukture.Poruka;

public class Primanje_tipke implements Runnable, Header {

	private Thread t;
	private byte[] primljeni_podaci;
	private DatagramSocket s;

	public Primanje_tipke(DatagramSocket socket) {
		this.s = socket;
		t = new Thread(this);
		t.start();
	}

	@Override
	public void run() {
		System.out.println("Primanje radi!");
		DatagramPacket primljeni_paket;

		while (true) {
			primljeni_podaci = new byte[2048];
			primljeni_paket = new DatagramPacket(primljeni_podaci,
					primljeni_podaci.length);
			try {
				s.receive(primljeni_paket);
				ByteArrayInputStream baos = new ByteArrayInputStream(primljeni_podaci);
				ObjectInputStream oos = new ObjectInputStream(baos);
				Poruka primljena_poruka = (Poruka) oos.readObject();
				//System.out.println("\nTipke: " + primljena_poruka.id_poruke);
				Glavna.poruka = primljena_poruka;
					
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}


		}

	}

}

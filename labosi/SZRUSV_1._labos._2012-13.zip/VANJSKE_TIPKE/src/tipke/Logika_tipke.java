package tipke;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import strukture.Lift_status;
import strukture.Naredba;
import strukture.Poruka;
import strukture.Potvrda;

public class Logika_tipke implements Runnable, Header {

	private Thread t;
	int otvorenost = 3;
	int k;
	//int[] lift_tipke = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int povecaj_cetvrt = 0;
	//int iduci_korak = 1;
	int salji_status = 0;
	int id = 0;
	int stani = 0;
	Lift_status lift_status;
	int kat = 0;
	int prikaz = 0;
	int[][]tipke_kat = new int[10][2];
	int broj = 0;

	public Logika_tipke() {
		t = new Thread(this, "Logika programa"); // pokretanje nove dretve
		lift_status = new Lift_status(STOJI, OTVORENA, 0, 0);
		t.start();
	}

	@Override
	public void run() {
		/**
		 * Logika tipki je zadu�ena za obradu primljenih poruka
		 * na naredbe odgovara sa potvrdom
		 * po dolasku naredbe mjenja stanja tipki i iscrtava na ekran stanja tipki i lifta
		 * Nema potrebe za mjerenjem vremena ni pove�anjem �etvrti
		 */
		
		
		/**
		 * ovaj program je potrebno na isti na�in izmjeniti kao i LIFT
		 * tako da prikazuje ekran na po�etku rada kad mu UPR po�alje zahtjev za prikaz
		 * 
		 * te nakon svake promjene neke od tipki
		 * 
		 * jedine vrste poruka koje prima su naredbe jer naredba je ujedno i potvrda na poruku o tipci
		 * 
		 * nakon svake naredbe program odgovara s potvrdom UPR-u
		 * 
		 * naredbe mogu do�i i samostalno od UPRa ako je lift stigao na neki kat
		 */

		for(int i = 0; i < 10; i++){
            for(int j = 0; j < 2; j++){
            	tipke_kat[i][j]=0;
            }
		}
		
		while (true) {

			try {
				Thread.currentThread();
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			Naredba naredba = null;
			Poruka poruka = null;


			if (Glavna.poruka != null) {
				poruka = Glavna.poruka;
				Glavna.poruka = null;

				switch (poruka.tip_poruke) {
				/*
				case LIFT_STATUS:
					Lift_status lift_status = (Lift_status) poruka.sadrzaj;
					break;
				*/
				case NAREDBA:
					naredba = (Naredba) poruka.sadrzaj;
					break;
				/*
				case TIPKA:
					Tipka tipka = (Tipka) poruka.sadrzaj;
					break;
				
				case POTVRDA:
					Potvrda potvrda = (Potvrda) poruka.sadrzaj;
					break;
					*/
				}
			}

			//po�etak logike
			if(naredba != null && naredba.naredba != NISTA){
				prikaz = 1;				
				//System.out.println("naredba: " + naredba.n + " " +naredba.n/10 +"/"+ naredba.n%10);
				switch(naredba.prikaz){
					case TIPKA_UPALI:
						//System.out.println("paljenje tipke");
						int n = naredba.n;
						switch (n) {
						case 1:
							tipke_kat[0][1]=1;
								//smjer gore
							break;
						
						case 90:
							tipke_kat[9][0]=1;
								//smjer dolje
							break;

						default:	
							tipke_kat[n/10][n%10]=1;
							}
						break;
							

						
					case TIPKA_UGASI:
						int n1 = naredba.n;
						switch (n1) {
						case 1:
							tipke_kat[0][1]=0;
								//smjer gore
							break;
						
						case 90:
							tipke_kat[9][0]=0;
								//smjer dolje
							break;

						default:
							
							tipke_kat[n1/10][n1%10]=0;
							
							break;
						}
						break;
	
				}
			}
			
			//kraj logike
			
			
			//ispis na ekran
			if(prikaz == 1){	//tu ide ovo prikaz == 1
				int i;
				prikaz = 0;
				String ispis = "AKTIVNI POZIVI PO KATOVIMA: ";
				for(i=9; i>=0; i--){
						ispis += "\n"+i;
						
						if(tipke_kat[i][1] == 1)
							ispis += " GORE";
						if(tipke_kat[i][0] == 1)
							ispis += " DOLJE";
					}
				
				System.out.println(ispis);
				
			}
			//kraj ispisa

			//ovo je vezano za slanje poruka
				if (naredba != null) {
				id++;
				Poruka nova_poruka = new Poruka();
				nova_poruka.id_poruke = id;
				//kop
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ObjectOutputStream oos = null;
				try {
					oos = new ObjectOutputStream(baos);
				} catch (IOException e1) {
					e1.printStackTrace();
				}//kop
				if (naredba != null) {
					nova_poruka.tip_poruke = POTVRDA;
					Potvrda potvrda = new Potvrda();
					nova_poruka.posiljatelj = TIPKE;
					potvrda.id_poruke = poruka.id_poruke;
					nova_poruka.sadrzaj = potvrda;
				}
				//kop
				try {
					oos.writeObject(nova_poruka);
					oos.flush();
					// get the byte array of the object
					byte[] buf = baos.toByteArray();

					int number = buf.length;
					byte[] data = new byte[4];

					// int -> byte[]
					for (int i = 0; i < 4; ++i) {
						int shift = i << 3; // i * 8
						data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
					}
					Glavna.udpSend(buf, UPRAVLJACKI_PORT);
				} catch (IOException e) {
					e.printStackTrace();
				}//kop
			}
		}

	}



}

package tipke;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

import strukture.Poruka;
import strukture.Tipka;

//glavni �eka da se pritisne ne�to na tipkovnici i �alje poruke
public class Glavna implements Header {
	static DatagramSocket s; // s je socket
	static Scanner input;
	static InetAddress localhost = null; // ona adresa od udp-a
	
	public static Poruka poruka = null;
	static int id = 0;
	public static void main(String[] args) {
		try {
			localhost = InetAddress.getLocalHost();
			s = new DatagramSocket(TIPKE_PORT);
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		new Logika_tipke();
		new Primanje_tipke(s);
		input = new Scanner(System.in);

		System.out.println("Utipkajte broj od 0 do 9 potom enter te znak \"g\" ili \"d\" i enter\n");
		while (true) {
			String input_iz_tipkovnice = input.next();
			char slovo = input_iz_tipkovnice.charAt(0);
			String input_iz_tipkovnice2 = input.next();
			char slovo2 = input_iz_tipkovnice2.charAt(0);
			
				
				Tipka tipka = new Tipka();
				id++;
			
				switch ((int) slovo) {
				case (int) '0':
					tipka.id_tipke = 1;
					break;
					
				case (int) '1':
					tipka.id_tipke = 10;
					break;

				case (int) '2':
					tipka.id_tipke = 20;
					break;

				case (int) '3':
					tipka.id_tipke = 30;
					break;

				case (int) '4':
					tipka.id_tipke = 40;
					break;

				case (int) '5':
					tipka.id_tipke = 50;
					break;

				case (int) '6':
					tipka.id_tipke = 60;
					break;

				case (int) '7':
					tipka.id_tipke = 70;
					break;

				case (int) '8':
					tipka.id_tipke = 80;
					break;

				case (int) '9':
					tipka.id_tipke = 90;
					break;
				}
				
				switch (slovo2) {
				case (int) 'g':
					if(slovo != '9')
					tipka.id_tipke = tipka.id_tipke+1;
					break;
				case (int) 'd':
					
					break;
				}
				
				if(slovo == '0')
					tipka.id_tipke = 1;

				
				salji_tipka(UPRAVLJACKI_PORT, tipka);
				System.out.println("saljem tipka " + tipka.id_tipke);
			
			}

		}
	
	
	static void salji_tipka(int gdje, Tipka tipka){

		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = id;
		nova_poruka1.tip_poruke = TIPKA;
		nova_poruka1.sadrzaj = tipka;
		nova_poruka1.posiljatelj = TIPKE;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();

			int number = buf.length;
			byte[] data = new byte[4];

			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}
	
	public static void udpSend(byte[] sendData, int primatelj) {

		DatagramPacket paket_za_slanje = new DatagramPacket(sendData,
				sendData.length, localhost, primatelj);
		try {
			s.send(paket_za_slanje);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}

package lift;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import lift.Header;

import strukture.Naredba;
import strukture.Poruka;
import strukture.Potvrda;



public class Primanje implements Runnable, Header { // sa runnable je definirana dretva

	private Thread t;
	private byte[] primljeni_podaci;
	private DatagramSocket s;
	
	Naredba naredba = null;
	Potvrda potvrda = null;
	int id = 0;

	public Primanje(DatagramSocket socket) {
		this.s = socket;
		t = new Thread(this); // pokretanje nove dretve u program se prenosi
								// socket
		t.start();
	}

	@Override
	public void run() {
		System.out.println("Primanje radi!");
		DatagramPacket primljeni_paket;

		while (true) { // petlja koja prima poruke
			primljeni_podaci = new byte[2048];
			primljeni_paket = new DatagramPacket(primljeni_podaci, primljeni_podaci.length);
			try {
				s.receive(primljeni_paket);
				ByteArrayInputStream baos = new ByteArrayInputStream(primljeni_podaci);
				ObjectInputStream oos = new ObjectInputStream(baos);
				Poruka primljena_poruka = (Poruka) oos.readObject();
								
				if (primljena_poruka != null) {
					switch (primljena_poruka.tip_poruke) {
					case NAREDBA:
						naredba = (Naredba) primljena_poruka.sadrzaj;
						id = primljena_poruka.id_poruke;
						//Logika_lifta.Lista_naredba.add(new NaredbaP(naredba.naredba, naredba.prikaz, naredba.n, id));
						Logika_lifta.naredba1 = (Naredba) primljena_poruka.sadrzaj;
						Logika_lifta.id_naredbe = primljena_poruka.id_poruke;
						break;

					case POTVRDA:
						potvrda = (Potvrda) primljena_poruka.sadrzaj;
						Logika_lifta.Lista_potvrda.add(new Potvrda(potvrda.id_poruke));
						break;
					}
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}


		}

	}

}

package strukture;

import java.io.Serializable;

public class Sadrzaj_poruke implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6790296463099942574L;

}

package strukture;

public class Naredba extends Sadrzaj_poruke {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9105748994050039656L;
	public int naredba;
	public int prikaz;
	public int n;


	public Naredba() {

	}

	public Naredba(int naredba, int prikaz, int n) {

		this.naredba = naredba ;
		this.prikaz = prikaz;
		this.n = n ;
	}
}
package strukture;

public class NaredbaP extends Sadrzaj_poruke {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9105748994050039656L;
	public int naredba;
	public int prikaz;
	public int n;
	public int id;

	public NaredbaP() {

	}

	public NaredbaP(int naredba, int prikaz, int n, int id) {

		this.naredba = naredba ;
		this.prikaz = prikaz;
		this.n = n ;
		this.id = id ;
	}
}
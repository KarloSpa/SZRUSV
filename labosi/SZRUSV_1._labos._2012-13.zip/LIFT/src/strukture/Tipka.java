package strukture;

public class Tipka extends Sadrzaj_poruke {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2433251450230898702L;
	public int id_tipke;
	public int id_posiljatelja;
	
	public Tipka() {

	}

	public Tipka(int id_tipke, int id_posiljatelja) {

		this.id_tipke = id_tipke;
		this.id_posiljatelja = id_posiljatelja;
	}
}

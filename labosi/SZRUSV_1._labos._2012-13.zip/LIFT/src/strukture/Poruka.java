package strukture;

import java.io.Serializable;

public class Poruka implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8292816836116275002L;
	public int id_poruke;
	public int posiljatelj;
	public int tip_poruke;
	public Sadrzaj_poruke sadrzaj;

}

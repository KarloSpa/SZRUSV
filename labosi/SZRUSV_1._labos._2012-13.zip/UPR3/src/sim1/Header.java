package sim1;
public interface Header {
	//BROJEVI PORTOVA
	final int UPRAVLJACKI_PORT = 20000;
	final int TIPKE_PORT = 20001;
	final int LIFT_PORT = 20002;
	final int LIFT2_PORT = 20003;
	final int LIFT3_PORT = 20004;
	
	//POSILJATELJ
	final int LIFT1 = 100;
	final int LIFT2 = 200;
	final int LIFT3 = 300;
	final int TIPKE = 600;
	final int UPR = 770;
	
	//OZNAKE TIPKI KATOVA
	final int PRIZEMLJE = 00;
	final int K1G = 11;
	final int K1D = 10;
	final int K2D = 20;
	//TAKO NEKAKO DALJE
	
	//NAREDBE
	final int ZAHTJEVAJ = 10;
	final int STANI_NA_IDUCEM = 11;
	final int PRIKAZI = 12;
	final int IDI_GORE = 13;
	final int IDI_DOLJE = 14;
	final int STANI_ODMAH = 15;	//PRISILNO ZAUSTAVLJANJE
	final int OTVORI = 16;
	final int ZATVORI = 17;
	final int NISTA = 0;
	final int KRAJ = 99;
	
	 
	
	//PRIKAZ	OVO VRIJEDI I ZA LIFT I ZA TIPKE VAN LIFTA
	final int LAMPICE = 21;
	final int TIPKA_UPALI = 22;
	final int TIPKA_UGASI = 23;
	final int DISPLEJ_LIFT = 24;	//ZA PRIKAZ SMJERA GIBANJA I KATA
	
	
	//STANJA
	final int STOJI = 30;
	final int DOLJE = 31;
	final int GORE = 32;
	final int OTVARA = 33;
	final int ZATVARA = 34;
	final int OTVORENA = 1;
	final int ZATVORENA = 2;
	final int STOJI_PRISILNO = 3;
	
	//TIPOVI PORUKA
	final int LIFT_STATUS = 1;
	final int NAREDBA = 2;
	final int TIPKA = 3;
	final int POTVRDA = 4;
	
	//TIPKE LIFTA
	final int KRENI = 69;	//ovo su�i i kao naredba
	final int STANI = 68;	//TODO
}

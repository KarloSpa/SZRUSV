package sim1;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;


import sim1.Header;
import sim1.Primanje_simulator3;

import strukture.Poruka;

/**
 * Upravlja�ki program
 * u glavnom dijelu se uspostavlja komunikacija putem UDP-a
 * pokre�e se dretva za Logiku UPR-a
 * te dretva za primanje poruka
 * dalje nema smisla da radi ovaj program te se uspavljiva na 10s nakon svakog prolaska korz while petlju
 */

public class Glavna implements Header {
	public static Poruka poruka = null;
	static DatagramSocket s; // s je socket

	static InetAddress localhost = null; // adresa od udp-a

	public static void main(String[] args) { 
		try {
			localhost = InetAddress.getLocalHost();
			s = new DatagramSocket(UPRAVLJACKI_PORT);
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		new Primanje_simulator3(s);
		new logika_sim3();

		System.out.println("Upravljanje radi:\n");
		while (true) {
			
			try {
				Thread.currentThread();
				Thread.sleep(10000);	//spava 10s
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}

	static void udpSend(byte[] sendData, int odrediste) { 
		DatagramPacket paket_za_slanje = new DatagramPacket(sendData,
				sendData.length, localhost, odrediste);
		try {
			s.send(paket_za_slanje);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}

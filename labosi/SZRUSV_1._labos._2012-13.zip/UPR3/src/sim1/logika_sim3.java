package sim1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Time;
import java.util.Calendar;
import java.util.LinkedList;

import sim1.Glavna;
import sim1.Header;

import strukture.Lift_status;
import strukture.Naredba;
import strukture.Poruka;
import strukture.Potvrda;
import strukture.Tipka;
import strukture.Spremnik;

/**
 * 
 * @author Ivan
 *
 *program se pokre�e zadnji (prvo lift i tipke)
 *kad se pokrene �alje liftu zahtjev za stanjem, vi�e zbog toga da ka�e liftu da prika�e stanja na ekranu
 *istu stvar radi za tipke kako bi se po prvi puta ispisala stanja tipki
 *
 */


public class logika_sim3 implements Runnable, Header {

	private Thread t;
	int n;
	static int id=0;
	int k;
	//stanja lifta i tipki se spremaju u nizove
	int[] lift_tipke = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };	//slika stanja tipki u liftu
	//gegistri su za tipke izvana
	int[] registar11 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] registar12 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	//ovo je za pozive iz lifta oni imaju ve�i prioritet
	int[] gore = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] dolje = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int aktivnost1 = 0;
	int prvi1 = 0;
	
	//nek sve bude static da se mo�e i u funkcijama koristit
	static Naredba naredba = null;
	//objekti koje primanje proslje�uje logici
	static Potvrda potvrda = null;
	static Lift_status lift_status1 = null; 
	static Tipka tipkeLift = null;
	static Potvrda potvrdaTipke = null;
	static Tipka tipkeVanjske = null;
	static int id_status = 0;
	//objekti koji se koriste za rad u logici
	static Lift_status status = null; 
	
	Time vrijeme11, vrijeme12, vreme1, vreme2, vreme3, vreme4, vreme5, vreme6;
	Calendar cal;
	int brojanje1 = 0;
	int zatvori1 = 0;
	int l1 = 0;
	int ponovo = 1;
	boolean dozvoli = false;

	int nastaviG = 0;
	int nastaviD = 0;
	
	/**
	 * Vezane liste za spremanje naredbi za koje su poslane i na koje se �eka odgovor (Spremnik)
	 * Te za naredbe liftu koje se �alju s vremenskim ka�njenjem jedna iza druge ako ih ima vi�e
	 */
	
	LinkedList<Spremnik> Lista_naredbi = new LinkedList<Spremnik>();
	LinkedList<Naredba> za_lift = new LinkedList<Naredba>();
	
	public logika_sim3() {
		t = new Thread(this, "Logika programa"); // pokretanje nove dretve
		naredba = new Naredba(ZAHTJEVAJ, 0, 0);
		status = new Lift_status(0, 0, 0, 0);
		
		t.start();
	}

	
	@Override
	public void run() {
		
		System.out.println("pokrenuta je dretva programa za logiku simulatora");
		
			try {
				Thread.currentThread();
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			naredba.naredba = PRIKAZI;
			naredba.prikaz = DISPLEJ_LIFT; 
			//Tipkama se �alje poruka prikazi za prvi prikaz na ekranu
			naredba_tipke();
			
			naredba.naredba = ZAHTJEVAJ;
			liftNaredba();
			
			cal = Calendar.getInstance();
			vreme3 = new Time(cal.getTimeInMillis());
			
			cal = Calendar.getInstance();
			vreme5 = new Time(cal.getTimeInMillis());
		while(true){
			
			
						
			//ovdje ide mjerenje vremena za zatvaranje vrata na liftu
			if(brojanje1 == 1){
				cal = Calendar.getInstance();
				vrijeme12 = new Time(cal.getTimeInMillis());
				if ((vrijeme12.getTime() - vrijeme11.getTime()) > 5000){
					brojanje1 = 0;
					zatvori1 = 1;
				}
			}
			
			/**
			 * Odavde se �alju poruke liftu
			 * Naredbe se �alju s odgodom jedna iza druge
			 */
			
			cal = Calendar.getInstance();
			vreme4 = new Time(cal.getTimeInMillis());
			
			if(vreme4.getTime() - vreme3.getTime() > 300){
				dozvoli = true;
				vreme3 = vreme4;
			}
			
			if(dozvoli == true){
				if(!za_lift.isEmpty()){
				naredba = za_lift.removeFirst();
				naredba_lift();
				dozvoli = false;
				}
			}
			
			
			cal = Calendar.getInstance();
			vreme6 = new Time(cal.getTimeInMillis());
			
			if(vreme6.getTime() - vreme5.getTime() > 4000){
				dozvoli = true;
				vreme5 = vreme6;
				naredba.naredba = NISTA;
				naredba_tipke();
				naredba.naredba = NISTA;
				naredba_lift();
			}
			
			
			try {
				Thread.currentThread();
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			/**
			 * Potrebno je na svaku poruku koja sti�e odgovoriti
			 * Potvrde se obra�uju tako da se mi�e naredba iz spremnika na koju se odgovara
			 */
	
			
			//obrada Potvrde iz lifta
			if(potvrda != null ){
				provjeri(potvrda);
				potvrda = null;
			}
			//obrada potvrde iz vanjskih tipki
			if(potvrdaTipke != null){
				provjeri(potvrdaTipke);
				potvrdaTipke = null;
			}
			

			//Obrada tipki iz lifta
			{
				if(tipkeLift != null){	//u svakom slu�aju treba poslati da se aktivira tipka ako ve� nije aktivna
					int kat;
					
					if(tipkeLift.id_tipke != STANI && tipkeLift.id_tipke != KRENI){				
					kat = tipkeLift.id_tipke;
					
					if((gore[kat] == 0) || (dolje[kat] == 0) ){	//treba postaviti u aktivno stanje
						if(kat != status.kat){	//ako lift nije na tom katu
						naredba.naredba = PRIKAZI;
						naredba.prikaz = TIPKA_UPALI;
						naredba.n = kat;
						//System.out.println("Tipka: " + tipkeLift.id_tipke);
						liftNaredba();
						naredba.naredba = ZAHTJEVAJ;
						liftNaredba();
						}
					}
					switch (aktivnost1) {
					case 0:	//miruje

						if(tipkeLift.id_tipke > status.kat){
							aktivnost1 = 1;
							gore[kat] = 1;
						}
						if(tipkeLift.id_tipke < status.kat){
							aktivnost1 = 2;
							dolje[kat] = 1;
						}
						System.out.println("aktivnost zadana iz lifta " +aktivnost1);
						break;
					case 1:	//gore

						if(tipkeLift.id_tipke > status.kat){
							gore[kat] = 1;
						}
						if(tipkeLift.id_tipke < status.kat){
							dolje[kat] = 1;
						}
						
						break;
					case 2:	//dolje

						if(tipkeLift.id_tipke > status.kat){
							gore[kat] = 1;
						}
						if(tipkeLift.id_tipke < status.kat){
							dolje[kat] = 1;
						}
						
						break;
					}
					
					
				}
					
						
						if(tipkeLift.id_tipke == STANI){
							naredba.naredba = STANI_ODMAH;
							liftNaredba();
						}
						if(tipkeLift.id_tipke == KRENI){
							naredba.naredba = KRENI;
							naredba.prikaz = status.stanja;
							naredba.n = status.vrata;
							liftNaredba();
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba();
						}	
					
				}tipkeLift = null;
				
			}//kraj tipke iz lifta

			{//Dolazi tipka iz vana
			if(tipkeVanjske != null){	//u svakom slu�aju treba poslati da se aktivira tipka ako ve� nije aktivna
	
				int kat = tipkeVanjske.id_tipke/10;
				int smjer = tipkeVanjske.id_tipke%10;
				System.out.println("smjer je " +smjer);
				if( ((smjer == 1) && (registar11[kat] == 0 )) || ((smjer == 0) && (registar12[kat] == 0 )) ){
				naredba.naredba = PRIKAZI;
				naredba.prikaz = TIPKA_UPALI;
				naredba.n = tipkeVanjske.id_tipke;
				naredba_tipke();
				}	
				
				switch (aktivnost1) {
				case 0:	//miruje
					if(smjer==1)
						registar11[kat]=1;
					if(smjer==0)
						registar12[kat]=1;
					//if (status.vrata == ZATVORENA) {
						if(smjer==1){
							aktivnost1 = 1;
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba();	
						}

						if(smjer==0){
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba();
							aktivnost1 = 2;
						}

						if(kat == status.kat){
							naredba.naredba = OTVORI; //TODO
							liftNaredba();
							aktivnost1 = 0;
						}
							
					//}
					System.out.println("aktivnost zadana iz vana " +aktivnost1);
					break;
				case 1:	//gore
					if(smjer==1)
						registar11[kat]=1;
					if(smjer==0)
						registar12[kat]=1;					
					
					break;
				case 2:	//dolje
					if(smjer==1)
						registar11[kat]=1;
					if(smjer==0)
						registar12[kat]=1;	

					break;
				}tipkeVanjske = null;
			}
			}//kraj vanjske tipke
			
			if(zatvori1 == 1){
				zatvori1 = 0;
				naredba.naredba = ZATVORI;
				liftNaredba();
			}
			
			if(lift_status1 != null){//Upravljanje liftom
				if(lift_status1.stanja != STOJI_PRISILNO)
				status = lift_status1;
				Potvrda pot = new Potvrda();
				pot.id_poruke = id_status;
				salji_potvrdu(LIFT_PORT, pot);
				
				//Lift stoji i vrata su otvorena, vrata treba zatvoriti nakon isteka vremena
				if(lift_status1.stanja == STOJI && lift_status1.vrata == OTVORENA){
					brojanje1 = 1;
					cal = Calendar.getInstance();
					vrijeme11 = new Time(cal.getTimeInMillis());
					prvi1 = 1; //ozna�ava da je lift ve� bio u stanju zatvorenih vrata (pri stajanju na kat)
				}
				//Lift stoji i vrata su zatvorena, zadaje se smjer gibanja lifta ovisno o aktivnosti ili se otvaraju vrata
				//ako je tek stao na taj kat - onda se bri�e kat iz registra
				if(lift_status1.stanja == STOJI && lift_status1.vrata == ZATVORENA){
					//1. ulazak zaustavljen lift
					if(prvi1 == 0){
						naredba.naredba = OTVORI;
						liftNaredba();
						int kat = lift_status1.kat; 
						switch (aktivnost1) {
						
						case 1:
							if(registar11[kat] == 1 || gore[kat] == 1){
								registar11[kat] = 0;
								gore[kat] = 0;
								gasiLft(kat);
								gasiVanjske(kat*10+1);
							}
							
							if(nastaviG == 1 && registar12[kat] == 1){
								registar12[kat] = 0;
								gore[kat] = 0;
								gasiLft(kat);
								gasiVanjske(kat*10);
							}
							
							break;
							
						case 2:
													
							if(registar12[kat] == 1 || dolje[kat] == 1){
								registar12[kat] = 0;
								dolje[kat] = 0;
								gasiLft(kat);
								gasiVanjske(kat*10);
							}
							
							if(nastaviD == 1 && registar11[kat] == 1){
								registar11[kat] = 0;
								dolje[kat] = 0;
								gasiLft(kat);
								gasiVanjske(kat*10+1);
							}
							break;
						}
					}
				
					//2. ulazak vrata bila otvorena te se zatvorila - ovdje se provjerava treba li pre�i u aktivnost miruje
					int kat = lift_status1.kat;
					if(prvi1 == 1){
						prvi1 = 0;
						nastaviG = 0;
						nastaviD = 0;
						switch (aktivnost1) {
						case 0:
							
							prvi1 = 1;
							break;
							
						case 1:
							if(nizGore(gore, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba();
								break;
							}
							
							//ako ima aktivnih katova iznad trenutnog u registru za gore
							if(nizGore(registar11, kat)){
							naredba.naredba = IDI_GORE;
							liftNaredba();
							}
							//ako nema aktivnih u smjeru prema gore ali ima aktivnih u smjeru prema dolje iznad trenutnog kata
							if(!nizGore(registar11, kat) & nizGore(registar12, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba();
								nastaviG = 1;
							}
							//ako nema aktivnih uop�e
							if(!nizGore(registar11, 0) & !nizGore(registar12, 0)){
								aktivnost1 = 0;
								nastaviG = 0;	
							}
							//ako ima aktivnih u smjeru pream dolje ispod trenutnog kata a nema nikakvih u smjeru prema gore, onda se mjenja smjer
							if(nizDolje(registar12, kat) & !nizGore(registar11, kat)){
								aktivnost1 = 2;
								naredba.naredba = IDI_DOLJE;
								liftNaredba();
							}
							//ako nema aktivnih u smjeru prema dolje od trenutnog ali ima u smjeru prema gore
							if(nizDolje(registar11, kat) & !nizGore(registar12, 0)){
								aktivnost1 = 2;
								nastaviD = 1;
								naredba.naredba = IDI_DOLJE;
								liftNaredba();
							}
							
							if(nizDolje(dolje, kat)){
								naredba.naredba = IDI_DOLJE;
								aktivnost1 = 2;
								liftNaredba();
								break;
							}
							
							break;
							
						case 2:
							
							if(nizDolje(dolje, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba();
								break;
							}
							
							if(nizDolje(registar12, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba();
								}
								
								if(!nizDolje(registar12, kat) & nizDolje(registar11, kat)){
									naredba.naredba = IDI_DOLJE;
									liftNaredba();
									nastaviD = 1;
								}
								
								if(!nizGore(registar12, 0) & !nizGore(registar11, 0)){
									aktivnost1 = 0;
									nastaviD = 0;
								}
								
								if(nizGore(registar11, kat) & !nizDolje(registar12, kat)){
									aktivnost1 = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba();
								}
								
								if(nizGore(registar12, kat) & !nizGore(registar11, 0)){
									aktivnost1 = 1;
									nastaviG = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba();
								}
								
								if(nizGore(gore, kat)){
									naredba.naredba = IDI_GORE;
									aktivnost1 = 1;
									liftNaredba();
									break;
								}
								
							break;
						}
					}
				}
				//Lift se giba gore
				if(lift_status1.stanja == GORE && lift_status1.cetvrtina == 2){	//primjer treba stat na 3.kat zna�i za 2.kat i 1/cetvrt mogu javit da stane
					int kat = lift_status1.kat;
						kat++;
					if(gore[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba();
					}
					
					if(registar11[kat] == 1 && nastaviG == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba();
					}
					if(registar12[kat] == 1 && nastaviG == 1){
						if(najveci(registar12, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba();
						}
					}
					
					
					
				}
				//Lift se giba dolje
				if(lift_status1.stanja == DOLJE && lift_status1.cetvrtina == 2){
					int kat = lift_status1.kat;
					
					if(dolje[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba();
					}
					
					if(registar12[kat] == 1 && nastaviD == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba();
					}
					if(registar11[kat] == 1 && nastaviD == 1){
						if(najmanji(registar11, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba();
						}
					}
					
				}
			lift_status1 = null;
			}//Kraj upravljanja
			
			if(ponovo == 0){
				cal = Calendar.getInstance();
				vreme2 = new Time(cal.getTimeInMillis());
				if(vreme2.getTime() - vreme1.getTime() > 6)
					ponovo = 1;
			}
			ponovo();
			//System.out.println("aktivnost = "+ aktivnost1 + " nG "+ nastaviG +" nD " + nastaviD + " zabrana " +zabrana);
			
		}//kraj while petlje
	}//kraj run-a
	
	
	/**
	 * nadalje su prikazane sve funkcije koje se koriste
	 */
	
	//funkcija za provjeru jeli niz ima elemenata koji su u 1 od kata prema gore
	private boolean nizGore(int[] b, int k){
		for(int i = k; i < b.length; i++){
			if(b[i] == 1)
				return true;
		}
		return false;
	}
	
	private boolean nizDolje(int[] b, int k){
		for(int i = k; i >= 0; i--){
			if(b[i] == 1)
				return true;
		}
		return false;
	}
	
	private int najveci(int[] b, int k){
		int broj = -1;
		for(int i = k; i < b.length; i++){
			if(b[i] == 1)
				broj = i;
		}
		return broj;
	}
	
	private int najmanji(int[] b, int k){
		int broj = -1;
		for(int i = k; i >= 0; i--){
			if(b[i] == 1)
				broj = i;
		}
		return broj;
	}
	
	
	//vra�a broj kata koji je najvi�i aktivan u nizu
	
	
	private void liftNaredba(){
		za_lift.add(new Naredba(naredba.naredba, naredba.prikaz, naredba.n));
	}
	
	private void gasiVanjske(int tipka){
		naredba.naredba = PRIKAZI;
		naredba.prikaz = TIPKA_UGASI;
		naredba.n = tipka;
		naredba_tipke();
	}
	
	private void gasiLft(int tipka){
		naredba.naredba = PRIKAZI;
		naredba.prikaz = TIPKA_UGASI;
		naredba.n = tipka;
		liftNaredba();
	}
	
	private void naredba_tipke() {
		salji_naredba(TIPKE_PORT, naredba, ++id);
		dodaj(TIPKE_PORT);
	}


	private void naredba_lift() {
		salji_naredba(LIFT_PORT, naredba, ++id);
		dodaj(LIFT_PORT);		
	}


	private void dodaj(int port) {
		Time v1;
		Calendar cal1;
		cal1 = Calendar.getInstance();
		v1 = new Time(cal1.getTimeInMillis());
		//System.out.println("dodana naredba na spremnik id = " + id);
		Lista_naredbi.add(new Spremnik(v1, id, port, naredba.naredba, naredba.prikaz, naredba.n));
	}

	/**
	 * 
	 * @param pot
	 * Provjerava jeli potvrda koja je stigla odgovor na naredbu koja je stavljen au listu za slanje
	 * ako je naredba se uklanja s liste
	 */
	private void provjeri(Potvrda pot){
		Spremnik Temp = new Spremnik();
		for (int h = 0; h < Lista_naredbi.size(); h++) {
			Temp = Lista_naredbi.get(h);
			if(Temp.id_naredbe == pot.id_poruke){
				Lista_naredbi.remove(h);
				//System.out.println("\nStigla potvrda za naredbu! "+pot.id_poruke +" Uklonjena naredba sa Spremnika");
				break;	//nema potrebe provjeravat dalje
			}
		}
	}
	
	private void ponovo(){
		//provjera ima li naredbe koja se treba slati
		if(!Lista_naredbi.isEmpty())
		{
		Spremnik Temp = Lista_naredbi.getFirst();
		int id_naredbe;
		int port;
		Naredba nar = new Naredba();
		//provjera vremena
		Time v2, v1;
		Calendar cal2;
		cal2 = Calendar.getInstance();
		v2 = new Time(cal2.getTimeInMillis());
		v1 = Temp.v1;
		if(v2.getTime() - v1.getTime() > 30){
		throw new IllegalStateException("Potvrda za naredbu nije stigla unutar zadanog vremeana");
		}
		if(v2.getTime() - v1.getTime() > 5 && ponovo == 1)
		{	ponovo = 0;
			//vrijeme slanja prethodne
			cal = Calendar.getInstance();
			vreme1 = new Time(cal.getTimeInMillis());
			id_naredbe = Temp.id_naredbe;
			port = Temp.odrediste;
			nar.n = Temp.n;
			nar.naredba = Temp.naredba;
			nar.prikaz = Temp.prikaz;
			salji_naredba(port, nar, id_naredbe);
			//System.out.println("Ponovno se �alje naredba s id-om "+id_naredbe);
		}

		}
	}
	
	static void salji_naredba(int gdje, Naredba naredba, int id_naredbe){
		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = id_naredbe;
		nova_poruka1.tip_poruke = NAREDBA;
		nova_poruka1.sadrzaj = naredba;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();
			int number = buf.length;
			byte[] data = new byte[4];
			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}
	
	static void salji_potvrdu(int gdje, Potvrda potvrda){
		id++;
		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = id;
		nova_poruka1.tip_poruke = POTVRDA;
		nova_poruka1.sadrzaj = potvrda;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();
			int number = buf.length;
			byte[] data = new byte[4];
			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
			//System.out.println("poslana potvrda ");
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}
	
}



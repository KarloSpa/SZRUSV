package strukture;

public class Potvrda extends Sadrzaj_poruke {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8941830107400501359L;
	public int id_poruke;
	
	public Potvrda() {

	}

	public Potvrda(int id_poruke) {

		this.id_poruke = id_poruke ;
	}
}

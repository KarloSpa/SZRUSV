package strukture;

public class Lift_status extends Sadrzaj_poruke {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3412914506484006279L;
	public int stanja;
	public int vrata;
	public int kat;
	public int cetvrtina;

	public Lift_status() {

	}

	public Lift_status(int stanje, int vrata, int kat, int cetvrtina) {

		this.stanja = stanje;
		this.vrata = vrata;
		this.kat = kat;
		this.cetvrtina = cetvrtina;
	}
}

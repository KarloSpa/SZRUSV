package lift;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Time;
import java.util.Calendar;
import java.util.LinkedList;



import strukture.Lift_status;
import strukture.Naredba;
import strukture.NaredbaP;
import strukture.Poruka;
import strukture.Potvrda;


/**
 * Jedino �to �alje ovaj program su statusi i potvrde
 * nakon �to se po�alje status �eka se na potvrdu od UDP-a
 *
 */

public class Logika_lifta implements Runnable, Header {

	private Thread t;
	int otvorenost = 3;
	int k;
	int[] lift_tipke = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int povecaj_cetvrt = 0;
	boolean promjena_tipke = false;
	static boolean salji_status = false;
	int stani = 0;
	Lift_status lift_status;
	Lift_status lift_staro;
	Time vrijeme1, vrijeme2;
	Calendar cal;
	boolean stigla_naredba = false;
	static Naredba naredba1 = new Naredba();
	static int id_prethodne_naredbe = 0;
	static int id_naredbe = 0;
	static Naredba naredba = new Naredba();
	
	//objekti u koje se spremaju pristigle poruke
	static LinkedList<Potvrda> Lista_potvrda = new LinkedList<Potvrda>();
	static LinkedList<NaredbaP> Lista_naredba = new LinkedList<NaredbaP>();

	public Logika_lifta() {
		t = new Thread(this, "Logika programa"); // pokretanje nove dretve
		lift_status = new Lift_status(STOJI, OTVORENA, 0, 0);
		lift_staro = new Lift_status(STOJI, OTVORENA, 0, 0);
		t.start();
	}

	@Override
	public void run() {
		cal = Calendar.getInstance();
		vrijeme1 = new Time(cal.getTimeInMillis());
		while (true) {
			cal = Calendar.getInstance();
			vrijeme2 = new Time(cal.getTimeInMillis());

			
			
			try {
				Thread.currentThread();
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			if ((vrijeme2.getTime() - vrijeme1.getTime()) > 250*4) {	
				vrijeme1.setTime(vrijeme2.getTime());
				povecaj_cetvrt = 1;
			}
			
			//prebacivanje naredbe iz liste NaredbaP u objekt Naredba
			// nadalje se na pristiglu naredbu odmah odgovara a ne na kraju petlje
			 
			
			// Naredba naredba = dohvati_naredbu();	
			if(naredba1 != null){
				naredba = naredba1;
				Potvrda potvrda = new Potvrda();
				potvrda.id_poruke = id_naredbe;
				salji_potvrdu(UPRAVLJACKI_PORT, potvrda);
				naredba1 = null;
			}
			
			
//ovdje po�ine dio vezan za stanja lifta
			
			switch (lift_status.stanja) {
			case STOJI:							//stoji
					switch (lift_status.vrata) {
					case OTVORENA:
						if (naredba != null) {
							if (naredba.naredba == ZATVORI) {
								lift_status.vrata = ZATVARA;
							}
						}
						break;
					case ZATVORENA:
						if (naredba != null) {
							switch (naredba.naredba) {
							case OTVORI:
								lift_status.vrata = OTVARA;
								break;
							case IDI_GORE:
								lift_status.stanja = GORE;
								if(lift_status.kat == 9)
									lift_status.stanja = STOJI;
								break;
							case IDI_DOLJE:
								lift_status.stanja = DOLJE;
								if(lift_status.kat == 0)
									lift_status.stanja = STOJI;
								break;
							}
						}
						break;
					case OTVARA:
						if(povecaj_cetvrt == 1){
						otvorenost++;
						povecaj_cetvrt = 0;
						}
						if (otvorenost == 2) {
							lift_status.vrata = OTVORENA;
						}
						break;
					case ZATVARA:
						if(povecaj_cetvrt == 1){
						otvorenost--;
						povecaj_cetvrt = 0;
						}
						if (otvorenost == 0) {
							lift_status.vrata = ZATVORENA;
						}
						break;
					}
				break;				//do tud je stoji
			case GORE:		//gore
				if (naredba != null) {
						if(naredba.naredba == STANI_NA_IDUCEM){
						stani = 1;
						}
					}
				if (povecaj_cetvrt == 1) {
					lift_status.cetvrtina++;
					povecaj_cetvrt = 0;
				}
				if (lift_status.cetvrtina == 4) {
					lift_status.cetvrtina = 0;
					lift_status.kat++;
				}
				if (lift_status.cetvrtina == 0 && stani == 1) {
					lift_status.stanja = STOJI;
					stani = 0;
				}
				if (lift_status.kat >= 9) {
					lift_status.stanja = STOJI;
				}
				break;		//do tud je gore
				
			case DOLJE:
				if (naredba != null) {
					if(naredba.naredba == STANI_NA_IDUCEM){
					stani = 1;
					}
				}
				if (povecaj_cetvrt == 1) {
					lift_status.cetvrtina--;
					povecaj_cetvrt = 0;
				}
				if (lift_status.cetvrtina == -1) {
					lift_status.cetvrtina = 3;
					lift_status.kat--;
				}
				if (lift_status.cetvrtina == 0 && stani == 1) {
					lift_status.stanja = STOJI;
					stani = 0;
				}
				if (lift_status.kat < 0 ) {
					lift_status.stanja = STOJI;
					lift_status.kat = 0;
					lift_status.cetvrtina = 0;
				}	
				break;		//do tud je dolje
				
			case STOJI_PRISILNO:
				
				break;
			}
			
			//u slu�aju da se tra�i trenutno zastavljanje lifta
			//ili ponovno pokretanje lifta iz STOJI_PRISILNO stanja
			if(naredba != null){
				switch (naredba.naredba) {
				case STANI_ODMAH:
					lift_status.stanja = STOJI_PRISILNO;
					break;
				case KRENI:					//vra�a lift u staro stanje
					lift_status.stanja = naredba.prikaz;	//u UPR-u treba definirati �ta �e se slati ovdje
					lift_status.vrata = naredba.n;	//TODO
					break;
				}			
			}			//kraj if-a
			
			if(naredba != null){
			//primanje naredbi za postavljanje tipki
			if(naredba.naredba == PRIKAZI && naredba.prikaz == TIPKA_UPALI){
				int n = naredba.n;
				lift_tipke[n] = 1;
				promjena_tipke = true;
			}
			
			if(naredba.naredba == PRIKAZI && naredba.prikaz == TIPKA_UGASI){
				int n = naredba.n;
				lift_tipke[n] = 0;
				promjena_tipke = true;
			}
			
			}
			
			if(naredba != null)
				if(naredba.naredba == ZAHTJEVAJ){
					salji_status = true;
					//System.out.println("Zahtjeva se status");
				}
			
			
			naredba = null;
			
						
			//kraj tipki
			
			//dio u kojem se provjerava je li lift promjenio neko od svojih stanja
			
			if((lift_staro.stanja != lift_status.stanja) || (lift_staro.vrata != lift_status.vrata) 
					|| (lift_staro.kat != lift_status.kat) || (lift_staro.cetvrtina != lift_status.cetvrtina) ){
				salji_status = true;
				
				lift_staro.stanja = lift_status.stanja;
				lift_staro.vrata = lift_status.vrata;
				lift_staro.kat = lift_status.kat;
				lift_staro.cetvrtina = lift_status.cetvrtina;
			}
			
			
			//ispis na ekran
				if(promjena_tipke | salji_status){	//ako je lift promjenio stanje i ako je dana naredba za promjenu stanja tipke
					String ispis = "\n\nLift3\nGibanje: ";
					promjena_tipke = false;
					switch (lift_status.stanja) {
					case STOJI:
						ispis += "stoji";
						break;
					case GORE:
						ispis += "ide gore";
						break;
					case DOLJE:
						ispis += "ide dolje";
						break;
					case STOJI_PRISILNO:
						ispis += "stoji prisilno";
						break;
					}
					
					ispis += "\nVrata: ";
					
					switch (lift_status.vrata) {
					case OTVARA:
						ispis += "otvaraju se";
						break;
					case ZATVARA:
						ispis += "zatvaraju se";
						break;
					case OTVORENA:
						ispis += "otvorena";
						break;
					case ZATVORENA:
						ispis += "zatvorena";
						break;
					}

					ispis += "\nKat: " + lift_status.kat + " \\ " + lift_status.cetvrtina + "\nPritisnute tipke: ";
					
					for (int i = 0; i < lift_tipke.length;) {
						if (lift_tipke[i] == 1) {
							ispis += i + " ";
						}i++;
					}
					System.out.println(ispis);
					System.out.println("\n\n\n\n\n");
				}
			
						
//ovdje zavr�ava dio vezan za stanja lifta
			

				/**
				 * lift uvjek odgovara na naredbe s potvrdom, �ak i ako je to naredba za status
				 * ako treba �alje se naredba za status nakon �ega se �eka na odgovor
				 */
				
				//slanje statusa
					if (salji_status) {	
						//System.out.println("saljem status \n");
						salji_status = false;
						salji_status(UPRAVLJACKI_PORT, lift_status);
						cekaj_potvrdu();
					} 
					
			}//kraj while

	}


	static Naredba dohvati_naredbu() {
		if(!Lista_naredba.isEmpty()){
			NaredbaP Temp = Lista_naredba.pop();
			try {
				naredba.naredba = Temp.naredba;
				naredba.prikaz = Temp.prikaz;
				naredba.n = Temp.n;
				if(Temp.id == id_prethodne_naredbe){
					naredba = null;
				}
				id_prethodne_naredbe = Temp.id;
				Potvrda potvrda = new Potvrda(Temp.id);
				//System.out.println("Stigla naredba s id-om = " + Temp.id);
				salji_potvrdu(UPRAVLJACKI_PORT, potvrda);
			} catch (NullPointerException e) {
			}
				
		}
		return naredba;
		
	}

	static void cekaj_potvrdu(){
		//System.out.println("O�ekujem potvrdu\n");
		Time v1;
		Time v2;
		Calendar cal2;
		int stigla = 0;
		cal2 = Calendar.getInstance();
		v1 = new Time(cal2.getTimeInMillis());
		while(stigla == 0){
		cal2 = Calendar.getInstance();
		v2 = new Time(cal2.getTimeInMillis());
		
		if (!Lista_potvrda.isEmpty()) {//TODO zamjeni da reagira na poruke u listi
			Potvrda potvrda = Lista_potvrda.removeFirst();
				if(potvrda.id_poruke == Glavna.id){
				stigla = 1;	//izlazak iz petlje
				//System.out.println("Stigao odgovor na poruku LIFT_STATUS id_poruke = " + Glavna.id);
				}					
		}
		else if(v2.getTime() - v1.getTime() > 10){
			stigla = 1;
			//throw new IllegalStateException("Isteklo vrijeme �ekanja na potvrdu poruke o statusu");
			System.out.println("GRE�KA: Isteklo vrijeme �ekanja na potvrdu poruke o statusu \n");
			salji_status = true;
		}
	}
	}
	
	static void salji_status(int gdje, Lift_status lift_status){
		Glavna.id++;
		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = Glavna.id;
		nova_poruka1.tip_poruke = LIFT_STATUS;
		nova_poruka1.sadrzaj = lift_status;
		nova_poruka1.posiljatelj = LIFT3;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();

			int number = buf.length;
			byte[] data = new byte[4];

			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}
	
	static void salji_potvrdu(int gdje, Potvrda potvrda){
		Glavna.id++;
		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = Glavna.id;
		nova_poruka1.tip_poruke = POTVRDA;
		nova_poruka1.sadrzaj = potvrda;
		nova_poruka1.posiljatelj = LIFT3;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();

			int number = buf.length;
			byte[] data = new byte[4];

			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}

}

package sim1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Time;
import java.util.Calendar;
import java.util.LinkedList;

import sim1.Glavna;
import sim1.Header;

import strukture.Lift_status;
import strukture.Naredba;
import strukture.Poruka;
import strukture.Potvrda;
import strukture.Tipka;
import strukture.Spremnik;

/**
 * 
 * @author Ivan
 *
 *program se pokre�e zadnji (prvo lift i tipke)
 *kad se pokrene �alje liftu zahtjev za stanjem, vi�e zbog toga da ka�e liftu da prika�e stanja na ekranu
 *istu stvar radi za tipke kako bi se po prvi puta ispisala stanja tipki
 *
 */


public class logika_sim3 implements Runnable, Header {

	private Thread t;
	int n;
	static int id=0;
	int k;
	//stanja lifta i tipki se spremaju u nizove
	int[] lift_tipke = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };	//slika stanja tipki u liftu
	//gegistri su za tipke izvana
	int[] registar11 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] registar12 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] registar21 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] registar22 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] registar31 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] registar32 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	//ovo je za pozive iz lifta oni imaju ve�i prioritet
	int[] gore1 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] dolje1 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int aktivnost1 = 0;
	int prvi1 = 0;
	
	//nek sve bude static da se mo�e i u funkcijama koristit
	static Naredba naredba = null;
	//objekti koje primanje proslje�uje logici
	static Potvrda potvrda = null;
	static Potvrda potvrda2 = null;
	static Potvrda potvrda3 = null;
	static Lift_status lift_status1 = null; 
	static Tipka tipkeLift1 = null;
	static Potvrda potvrdaTipke = null;
	static Tipka tipkeVanjske = null;
	static int id_status1 = 0;
	//objekti koji se koriste za rad u logici
	static Lift_status status1 = null; 
	
	
	static Lift_status lift_status2 = null; 
	static Lift_status status2 = null; 
	static int id_status2 = 0;
	static Tipka tipkeLift2 = null;
	int[] gore2 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] dolje2 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int aktivnost2 = 0;
	int prvi2 = 0;
	
	
	static Lift_status lift_status3 = null; 
	static Lift_status status3 = null; 
	static int id_status3 = 0;
	static Tipka tipkeLift3 = null;
	int[] gore3 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int[] dolje3 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	int aktivnost3 = 0;
	int prvi3 = 0;
	
	
	
	
	
	Time vrijeme11, vrijeme12, vreme1, vreme2, vreme31, vreme41, vreme5, vreme6;
	Time vrijeme21, vrijeme22, vreme32, vreme42;
	Time vrijeme31, vrijeme32, vreme33, vreme43;
	
	Calendar cal;
	int brojanje1 = 0;
	int zatvori1 = 0;
	int l1 = 0;
	int ponovo = 1;
	boolean dozvoli1 = false;
	boolean dozvoli2 = false;
	boolean dozvoli3 = false;

	int nastaviG = 0;
	int nastaviD = 0;
	int nastaviG2 = 0;
	int nastaviD2 = 0;
	int nastaviG3 = 0;
	int nastaviD3 = 0;
	
	int brojanje2 = 0;
	int zatvori2 = 0;
	int brojanje3 = 0;
	int zatvori3 = 0;
	
	int g1, g2, g3, d1, d2, d3, pg, pd;
	int ne;
	
	/**
	 * Vezane liste za spremanje naredbi za koje su poslane i na koje se �eka odgovor (Spremnik)
	 * Te za naredbe liftu koje se �alju s vremenskim ka�njenjem jedna iza druge ako ih ima vi�e
	 */
	
	LinkedList<Spremnik> Lista_naredbi = new LinkedList<Spremnik>();
	LinkedList<Naredba> za_lift1 = new LinkedList<Naredba>();
	LinkedList<Naredba> za_lift2 = new LinkedList<Naredba>();
	LinkedList<Naredba> za_lift3 = new LinkedList<Naredba>();
	
	public logika_sim3() {
		t = new Thread(this, "Logika programa"); // pokretanje nove dretve
		naredba = new Naredba(ZAHTJEVAJ, 0, 0);
		status2 = new Lift_status(0, 0, 0, 0);
		
		t.start();
	}

	
	@Override
	public void run() {
		
		System.out.println("pokrenuta je dretva programa za logiku simulatora");
		
			try {
				Thread.currentThread();
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			naredba.naredba = PRIKAZI;
			naredba.prikaz = DISPLEJ_LIFT; 
			//Tipkama se �alje poruka prikazi za prvi prikaz na ekranu
			naredba_tipke();
			
			naredba.naredba = ZAHTJEVAJ;
			liftNaredba1();
			
			naredba.naredba = ZAHTJEVAJ;
			liftNaredba2();
			
			naredba.naredba = ZAHTJEVAJ;
			liftNaredba3();
			
			cal = Calendar.getInstance();
			vreme31 = new Time(cal.getTimeInMillis());
			vreme32 = new Time(cal.getTimeInMillis());
			vreme33 = new Time(cal.getTimeInMillis());
			
			cal = Calendar.getInstance();
			vreme5 = new Time(cal.getTimeInMillis());
		while(true){
			
			
						
			//ovdje ide mjerenje vremena za zatvaranje vrata na liftu
			if(brojanje1 == 1){
				cal = Calendar.getInstance();
				vrijeme12 = new Time(cal.getTimeInMillis());
				if ((vrijeme12.getTime() - vrijeme11.getTime()) > 5000){
					brojanje1 = 0;
					zatvori1 = 1;
				}
			}
			
			if(brojanje2 == 1){
				cal = Calendar.getInstance();
				vrijeme22 = new Time(cal.getTimeInMillis());
				if ((vrijeme22.getTime() - vrijeme21.getTime()) > 5000){
					brojanje2 = 0;
					zatvori2 = 1;
				}
			}
			
			if(brojanje3 == 1){
				cal = Calendar.getInstance();
				vrijeme32 = new Time(cal.getTimeInMillis());
				if ((vrijeme32.getTime() - vrijeme31.getTime()) > 5000){
					brojanje3 = 0;
					zatvori3 = 1;
				}
			}
			
			/**
			 * Odavde se �alju poruke liftu
			 * Naredbe se �alju s odgodom jedna iza druge
			 */
			
			cal = Calendar.getInstance();
			vreme41 = new Time(cal.getTimeInMillis());
			
			if(vreme41.getTime() - vreme31.getTime() > 300){
				dozvoli1 = true;
				vreme31 = vreme41;
			}
			
			if(dozvoli1 == true){
				if(!za_lift1.isEmpty()){
				naredba = za_lift1.removeFirst();
				naredba_lift1();
				dozvoli1 = false;
				}
			}
			
			cal = Calendar.getInstance();
			vreme42 = new Time(cal.getTimeInMillis());
			 
			 if(vreme42.getTime() - vreme32.getTime() > 300){
				dozvoli2 = true;
				vreme32 = vreme42;
			}
			 
			 if(dozvoli2 == true){
				if(!za_lift2.isEmpty()){
				naredba = za_lift2.removeFirst();
				naredba_lift2();
				dozvoli2 = false;
				}
			}
			
			 cal = Calendar.getInstance();
				vreme43 = new Time(cal.getTimeInMillis());
				 
				 if(vreme43.getTime() - vreme33.getTime() > 300){
					dozvoli3 = true;
					vreme33 = vreme43;
				}
				 
				 if(dozvoli3 == true){
					if(!za_lift3.isEmpty()){
					naredba = za_lift3.removeFirst();
					naredba_lift3();
					dozvoli3 = false;
					}
				}
		
			
			
			
			cal = Calendar.getInstance();
			vreme6 = new Time(cal.getTimeInMillis());
			
			if(vreme6.getTime() - vreme5.getTime() > 4000){
				dozvoli1 = true;
				vreme5 = vreme6;
				naredba.naredba = NISTA;
				naredba_tipke();
				naredba.naredba = NISTA;
				naredba_lift1();
				naredba.naredba = NISTA;
				naredba_lift2();
				naredba.naredba = NISTA;
				naredba_lift3();
			}
			
			
			try {
				Thread.currentThread();
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			/**
			 * Potrebno je na svaku poruku koja sti�e odgovoriti
			 * Potvrde se obra�uju tako da se mi�e naredba iz spremnika na koju se odgovara
			 */
	
			
			//obrada Potvrde iz lifta
			if(potvrda != null ){
				provjeri(potvrda);
				potvrda = null;
			}
			
			if(potvrda2 != null ){
				provjeri(potvrda2);
				potvrda2 = null;
			}
			
			if(potvrda3 != null ){
				provjeri(potvrda3);
				potvrda3 = null;
			}
			//obrada potvrde iz vanjskih tipki
			if(potvrdaTipke != null){
				provjeri(potvrdaTipke);
				potvrdaTipke = null;
			}
			

			//Obrada tipki iz lifta
			//prvi lift
			{
				if(tipkeLift1 != null){	//u svakom slu�aju treba poslati da se aktivira tipka ako ve� nije aktivna
					int kat;
					
					if(tipkeLift1.id_tipke != STANI && tipkeLift1.id_tipke != KRENI){				
					kat = tipkeLift1.id_tipke;
					
					if((gore1[kat] == 0) || (dolje1[kat] == 0) ){	//treba postaviti u aktivno stanje
						if(kat != status1.kat){	//ako lift nije na tom katu
						naredba.naredba = PRIKAZI;
						naredba.prikaz = TIPKA_UPALI;
						naredba.n = kat;
						//System.out.println("Tipka: " + tipkeLift.id_tipke);
						liftNaredba1();
						naredba.naredba = ZAHTJEVAJ;
						liftNaredba1();
						}
					}
					switch (aktivnost1) {
					case 0:	//miruje

						if(tipkeLift1.id_tipke > status1.kat){
							aktivnost1 = 1;
							gore1[kat] = 1;
						}
						if(tipkeLift1.id_tipke < status1.kat){
							aktivnost1 = 2;
							dolje1[kat] = 1;
						}
						System.out.println("aktivnost zadana iz lifta " +aktivnost1);
						break;
					case 1:	//gore

						if(tipkeLift1.id_tipke > status1.kat){
							gore1[kat] = 1;
						}
						if(tipkeLift1.id_tipke < status1.kat){
							dolje1[kat] = 1;
						}
						
						break;
					case 2:	//dolje

						if(tipkeLift1.id_tipke > status1.kat){
							gore1[kat] = 1;
						}
						if(tipkeLift1.id_tipke < status1.kat){
							dolje1[kat] = 1;
						}
						
						break;
					}

				}

						if(tipkeLift1.id_tipke == STANI){
							naredba.naredba = STANI_ODMAH;
							liftNaredba1();
						}
						if(tipkeLift1.id_tipke == KRENI){
							naredba.naredba = KRENI;
							naredba.prikaz = status1.stanja;
							naredba.n = status1.vrata;
							liftNaredba1();
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba1();
						}	
					
				}tipkeLift1 = null;
				
			}//kraj tipke iz lifta
			
			
			//drugi lift
			{
				if(tipkeLift2 != null){	//u svakom slu�aju treba poslati da se aktivira tipka ako ve� nije aktivna
					int kat;
					
					if(tipkeLift2.id_tipke != STANI && tipkeLift2.id_tipke != KRENI){				
					kat = tipkeLift2.id_tipke;
					
					if((gore2[kat] == 0) || (dolje2[kat] == 0) ){	//treba postaviti u aktivno stanje
						if(kat != status2.kat){	//ako lift nije na tom katu
						naredba.naredba = PRIKAZI;
						naredba.prikaz = TIPKA_UPALI;
						naredba.n = kat;
						//System.out.println("Tipka: " + tipkeLift.id_tipke);
						liftNaredba2();
						naredba.naredba = ZAHTJEVAJ;
						liftNaredba2();
						}
					}
					switch (aktivnost2) {
					case 0:	//miruje

						if(tipkeLift2.id_tipke > status2.kat){
							aktivnost2 = 1;
							gore2[kat] = 1;
						}
						if(tipkeLift2.id_tipke < status2.kat){
							aktivnost2 = 2;
							dolje2[kat] = 1;
						}
						System.out.println("aktivnost zadana iz lifta " +aktivnost1);
						break;
					case 1:	//gore

						if(tipkeLift2.id_tipke > status2.kat){
							gore2[kat] = 1;
						}
						if(tipkeLift2.id_tipke < status2.kat){
							dolje2[kat] = 1;
						}
						
						break;
					case 2:	//dolje

						if(tipkeLift2.id_tipke > status2.kat){
							gore2[kat] = 1;
						}
						if(tipkeLift2.id_tipke < status2.kat){
							dolje2[kat] = 1;
						}
						
						break;
					}

				}

						if(tipkeLift2.id_tipke == STANI){
							naredba.naredba = STANI_ODMAH;
							liftNaredba2();
						}
						if(tipkeLift2.id_tipke == KRENI){
							naredba.naredba = KRENI;
							naredba.prikaz = status2.stanja;
							naredba.n = status2.vrata;
							liftNaredba2();
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba2();
						}	
					
				}tipkeLift2 = null;
				
			}//kraj tipke iz lifta
			
			//tre�i lift
			{
				if(tipkeLift3 != null){	//u svakom slu�aju treba poslati da se aktivira tipka ako ve� nije aktivna
					int kat;
					
					if(tipkeLift3.id_tipke != STANI && tipkeLift3.id_tipke != KRENI){				
					kat = tipkeLift3.id_tipke;
					
					if((gore3[kat] == 0) || (dolje3[kat] == 0) ){	//treba postaviti u aktivno stanje
						if(kat != status3.kat){	//ako lift nije na tom katu
						naredba.naredba = PRIKAZI;
						naredba.prikaz = TIPKA_UPALI;
						naredba.n = kat;
						//System.out.println("Tipka: " + tipkeLift.id_tipke);
						liftNaredba3();
						naredba.naredba = ZAHTJEVAJ;
						liftNaredba3();
						}
					}
					switch (aktivnost3) {
					case 0:	//miruje

						if(tipkeLift3.id_tipke > status3.kat){
							aktivnost3 = 1;
							gore3[kat] = 1;
						}
						if(tipkeLift3.id_tipke < status3.kat){
							aktivnost3 = 2;
							dolje3[kat] = 1;
						}
						System.out.println("aktivnost zadana iz lifta " +aktivnost1);
						break;
					case 1:	//gore

						if(tipkeLift3.id_tipke > status3.kat){
							gore3[kat] = 1;
						}
						if(tipkeLift3.id_tipke < status3.kat){
							dolje3[kat] = 1;
						}
						
						break;
					case 2:	//dolje

						if(tipkeLift3.id_tipke > status3.kat){
							gore3[kat] = 1;
						}
						if(tipkeLift3.id_tipke < status3.kat){
							dolje3[kat] = 1;
						}
						
						break;
					}
					
					
				}
					
						
						if(tipkeLift3.id_tipke == STANI){
							naredba.naredba = STANI_ODMAH;
							liftNaredba3();
						}
						if(tipkeLift3.id_tipke == KRENI){
							naredba.naredba = KRENI;
							naredba.prikaz = status3.stanja;
							naredba.n = status3.vrata;
							liftNaredba3();
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba3();
						}	
					
				}tipkeLift3 = null;
				
			}//kraj tipke iz lifta
			
			
			
			
			
			
			
			
			/**
			 * kad do�e tipka iz vana onda se odre�uje koji lift �e poslu�iti taj zahtjev
			 */
			
			
			

			{//Dolazi tipka iz vana
			if(tipkeVanjske != null){	//u svakom slu�aju treba poslati da se aktivira tipka ako ve� nije aktivna
	
				int kat = tipkeVanjske.id_tipke/10;
				int smjer = tipkeVanjske.id_tipke%10;
				System.out.println("smjer je " +smjer);
				if( ((smjer == 1) && (registar11[kat] == 0 || registar21[kat] == 0 || registar31[kat] == 0)) 
						|| ((smjer == 0) && (registar12[kat] == 0 || registar22[kat] == 0 || registar32[kat] == 0 )) ){
					if(!(status1.kat == kat || status2.kat == kat || status3.kat == kat)){
						naredba.naredba = PRIKAZI;
						naredba.prikaz = TIPKA_UPALI;
						naredba.n = tipkeVanjske.id_tipke;
						naredba_tipke();
					}
				
				}	
				//dodjeljivanje zahtjeva odre�enom liftu
				
				//pomo�ne varijable
				g1 = g2 = g3 = d1 = d2 = d3 = pg = pd = 0;
				ne = 0;
				switch (smjer) {
				//zahtjev za gore
				case 1:
					//lift koji je bli�i ima prednost
					//u slu�aju da je kat iznad liftova koji se gibaju
					if(aktivnost1 == 1){
						if(kat > status1.kat){
							g1 = kat-status1.kat;
							pg = 1;
						}
					}
					if(aktivnost2 == 1){
						if(kat > status2.kat){
							g2 = kat-status2.kat;
							if(pg == 0)
								pg = 2;
							if(pg == 1 && g1 > g2)
								pg = 2;
						}	
					}
					if(aktivnost3 == 1){
						if(kat > status3.kat){
							g3 = kat-status3.kat;
							if(pg == 0)
								pg = 3;
							if(pg == 1 && g1 > g3)
								pg = 3;
							if(pg == 2 && g2 > g3)
								pg = 3;
						}	
					}
					
					//u slu�aju da lift miruje, gleda se modulo udaljenosti
					if(aktivnost1 == 0){
						 	g1 = Math.abs(status1.kat - kat);
						 	pg = 1;
					}
					if(aktivnost2 == 0){
							g2 = Math.abs(status2.kat - kat);
							if(pg == 0)
								pg = 2;
							if(pg == 1 && g1 > g2)
								pg = 2;	
					}
					if(aktivnost3 == 0){
							g3 = Math.abs(status3.kat - kat);
							if(pg == 0)
								pg = 3;
							if(pg == 1 && g1 > g3)
								pg = 3;
							if(pg == 2 && g2 > g3)
								pg = 3;
					}
					
					
						//u slu�aju da neki lift miruje i da je zahtjev do�ao s kata na kojemu se lift nalazi
						if(aktivnost1 == 0 && kat == status1.kat){
							naredba.naredba = OTVORI; 
							liftNaredba1();
							aktivnost1 = 1;
							naredba.naredba = PRIKAZI;
							naredba.prikaz = TIPKA_UGASI;
							naredba.n = tipkeVanjske.id_tipke;
							naredba_tipke();
							pg = 0;
							ne = 1;
						}
						
						if(aktivnost2 == 0 && kat == status2.kat && ne == 0){
							naredba.naredba = OTVORI; 
							liftNaredba2();
							aktivnost2 = 1;
							naredba.naredba = PRIKAZI;
							naredba.prikaz = TIPKA_UGASI;
							naredba.n = tipkeVanjske.id_tipke;
							naredba_tipke();
							pg = 0;
							ne = 1;
						}
						
						if(aktivnost3 == 0 && kat == status3.kat && ne == 0){
							naredba.naredba = OTVORI; 
							liftNaredba3();
							aktivnost3 = 1;
							naredba.naredba = PRIKAZI;
							naredba.prikaz = TIPKA_UGASI;
							naredba.n = tipkeVanjske.id_tipke;
							naredba_tipke();
							pg = 0;
							ne = 1;
						}
						
						//u slu�aju da se svi liftovi gibaju dolje zahtjev �e obraditi lift koji je najni�i
						//jer �e on najprije zavr�iti sa poslu�ivanjem prema dolje
						if(aktivnost1 == 2 && aktivnost2 == 2 && aktivnost3 == 2){
							if(status1.kat <= status2.kat && status1.kat <= status3.kat)
								pg = 1;
							if(status2.kat <= status3.kat && status2.kat <= status1.kat)
								pg = 2;
							if(status3.kat <= status2.kat && status3.kat <= status1.kat)
								pg = 3;
						}
						//ako se svi liftovi gibaju gore a kat je ispod svih
						if(aktivnost1 == 1 && aktivnost2 == 1 && aktivnost3 == 1  && status1.kat > kat && status2.kat > kat && status3.kat > kat){
							pg = 2;
						}
					
						if(ne == 0 && pg == 0){
							if(aktivnost1 == 2){
								registar11[kat]=1;
								ne = 1;
							}
								
							if(aktivnost2 == 2 && ne == 0){
								registar21[kat]=1;
								ne = 1;
							}
								
							if(aktivnost3 == 2 && ne == 0){
								registar31[kat]=1;
								ne = 1;
							}
								
						}
					//dodjelivanje zahtjeva liftu
					//ako lift miruje zadaje mu se aktivnost za gore
					if(ne == 0){
					switch (pg) {
					case 1:
						registar11[kat]=1;
						if(aktivnost1 == 0){
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba1();
							aktivnost1 = 1;
						}
						break;

					case 2:
						registar21[kat]=1;
						if(aktivnost2 == 0){
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba2();
							aktivnost2 = 1;
						}

						break;
						
					case 3:
						registar31[kat]=1;
						if(aktivnost3 == 0){
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba3();
							aktivnost3 = 1;
						}
							
						break;
					}
					}					
					break;
				
					
					
					
					
				//zahtjev za dolje TODO
				case 0:
					//provjera stanja pojedinog lifta
					if(aktivnost1 == 2){
						if(kat < status1.kat){
							d1 = status1.kat-kat;
							pd = 1;
						}
					}
					if(aktivnost2 == 2){
						if(kat < status2.kat){
							d2 = status2.kat-kat;
							if(pd == 0)
								pd = 2;
							if(pd == 1 && d1 > d2)
								pd = 2;
						}	
					}
					if(aktivnost3 == 2){
						if(kat < status3.kat){
							d3 = status3.kat-kat;
							if(pd == 0)
								pd = 3;
							if(pd == 1 && d1 > d3)
								pd = 3;
							if(pd == 2 && d2 > d3)
								pd = 3;
						}	
					}
					
					//u slu�aju da lift miruje, gleda se modulo udaljenosti
					if(aktivnost1 == 0){
						 	d1 = Math.abs(status1.kat - kat);
						 	pd = 1;
					}
					if(aktivnost2 == 0){
							d2 = Math.abs(status2.kat - kat);
							if(pd == 0)
								pd = 2;
							if(pd == 1 && d1 > d2)
								pd = 2;	
					}
					if(aktivnost3 == 0){
							d3 = Math.abs(status3.kat - kat);
							if(pd == 0)
								pd = 3;
							if(pd == 1 && d1 > d3)
								pd = 3;
							if(pd == 2 && d2 > d3)
								pd = 3;
					}
					
						
						if(aktivnost1 == 0 && kat == status1.kat){
							naredba.naredba = OTVORI; 
							liftNaredba1();
							aktivnost1 = 2;
							ne = 1;
							pd = 0;
							naredba.naredba = PRIKAZI;
							naredba.prikaz = TIPKA_UGASI;
							naredba.n = tipkeVanjske.id_tipke;
							naredba_tipke();
						}
						
						if(aktivnost2 == 0 && kat == status2.kat && ne == 0){
							naredba.naredba = OTVORI; 
							liftNaredba2();
							aktivnost2 = 2;
							ne = 1;
							pd = 0;
							naredba.naredba = PRIKAZI;
							naredba.prikaz = TIPKA_UGASI;
							naredba.n = tipkeVanjske.id_tipke;
							naredba_tipke();
						}
						
						if(aktivnost3 == 0 && kat == status3.kat && ne == 0){
							naredba.naredba = OTVORI; 
							liftNaredba3();
							aktivnost3 = 2;
							pd = 0;
							ne = 1;
							naredba.naredba = PRIKAZI;
							naredba.prikaz = TIPKA_UGASI;
							naredba.n = tipkeVanjske.id_tipke;
							naredba_tipke();
							
						}
						
						if(aktivnost1 == 1 && aktivnost2 == 1 && aktivnost3 == 1){
							if(status1.kat >= status2.kat && status1.kat >= status3.kat)
								pd = 1;
							if(status2.kat >= status3.kat && status2.kat >= status1.kat)
								pd = 2;
							if(status3.kat >= status2.kat && status3.kat >= status1.kat)
								pd = 3;
						}
					
						if(aktivnost1 == 2 && aktivnost2 == 2 && aktivnost3 == 2  && status1.kat < kat && status2.kat < kat && status3.kat < kat){
							pg = 3;
						}
						
						if(ne == 0 && pg == 0){
							if(aktivnost1 == 1){
								registar12[kat]=1;
								ne = 1;
							}
								
							if(aktivnost2 == 1 && ne == 0){
								registar22[kat]=1;
								ne = 1;
							}
								
							if(aktivnost3 == 1 && ne == 0){
								registar32[kat]=1;
								ne = 1;
							}
								
						}
					
					if(ne == 0){
					switch (pd) {
					case 1:
						registar12[kat]=1;
						if(aktivnost1 == 0){
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba1();
							aktivnost1 = 2;
						}
						break;

					case 2:
						registar22[kat]=1;
						if(aktivnost2 == 0){
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba2();
							aktivnost2 = 2;
						}

						break;
						
					case 3:
						registar32[kat]=1;
						if(aktivnost3 == 0){
							naredba.naredba = ZAHTJEVAJ;
							liftNaredba3();
							aktivnost3 = 2;
						}
							
						break;
					}
					}					
					break;
				}
				
				tipkeVanjske = null;
			}
			}//kraj vanjske tipke
			
			
			
			
			
			
			
			
			if(zatvori1 == 1){
				zatvori1 = 0;
				naredba.naredba = ZATVORI;
				liftNaredba1();
			}
			
			if(zatvori2 == 1){
				zatvori2 = 0;
				naredba.naredba = ZATVORI;
				liftNaredba2();
			}
			
			if(zatvori3 == 1){
				zatvori3 = 0;
				naredba.naredba = ZATVORI;
				liftNaredba3();
			}
			
			
			
			/**
			 * Upravljanje liftovima
			 */
			
			
			
			if(lift_status1 != null){//Upravljanje liftom1
				if(lift_status1.stanja != STOJI_PRISILNO)
				status1 = lift_status1;
				Potvrda pot = new Potvrda();
				pot.id_poruke = id_status1;
				salji_potvrdu(LIFT_PORT, pot);
				
				//Lift stoji i vrata su otvorena, vrata treba zatvoriti nakon isteka vremena
				if(lift_status1.stanja == STOJI && lift_status1.vrata == OTVORENA){
					brojanje1 = 1;
					cal = Calendar.getInstance();
					vrijeme11 = new Time(cal.getTimeInMillis());
					prvi1 = 1; //ozna�ava da je lift ve� bio u stanju zatvorenih vrata (pri stajanju na kat)
				}
				//Lift stoji i vrata su zatvorena, zadaje se smjer gibanja lifta ovisno o aktivnosti ili se otvaraju vrata
				//ako je tek stao na taj kat - onda se bri�e kat iz registra
				if(lift_status1.stanja == STOJI && lift_status1.vrata == ZATVORENA){
					//1. ulazak zaustavljen lift
					if(prvi1 == 0){
						naredba.naredba = OTVORI;
						liftNaredba1();
						int kat = lift_status1.kat; 
						switch (aktivnost1) {
						
						case 1:
							if(registar11[kat] == 1 || gore1[kat] == 1){
								registar11[kat] = 0;
								gore1[kat] = 0;
								gasiLft1(kat);
								gasiVanjske(kat*10+1);
							}
							
							if(nastaviG == 1 && registar12[kat] == 1){
								registar12[kat] = 0;
								gore1[kat] = 0;
								gasiLft1(kat);
								gasiVanjske(kat*10);
							}
							
							break;
							
						case 2:
													
							if(registar12[kat] == 1 || dolje1[kat] == 1){
								registar12[kat] = 0;
								dolje1[kat] = 0;
								gasiLft1(kat);
								gasiVanjske(kat*10);
							}
							
							if(nastaviD == 1 && registar11[kat] == 1){
								registar11[kat] = 0;
								dolje1[kat] = 0;
								gasiLft1(kat);
								gasiVanjske(kat*10+1);
							}
							break;
						}
					}
				
					//2. ulazak vrata bila otvorena te se zatvorila - ovdje se provjerava treba li pre�i u aktivnost miruje
					int kat = lift_status1.kat;
					if(prvi1 == 1){
						prvi1 = 0;
						nastaviG = 0;
						nastaviD = 0;
						switch (aktivnost1) {
						case 0:
							
							prvi1 = 1;
							break;
							
						case 1:
							if(nizGore(gore1, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba1();
								break;
							}
							
							//ako ima aktivnih katova iznad trenutnog u registru za gore
							if(nizGore(registar11, kat)){
							naredba.naredba = IDI_GORE;
							liftNaredba1();
							}
							//ako nema aktivnih u smjeru prema gore ali ima aktivnih u smjeru prema dolje iznad trenutnog kata
							if(!nizGore(registar11, kat) & nizGore(registar12, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba1();
								nastaviG = 1;
							}
							//ako nema aktivnih uop�e
							if(!nizGore(registar11, 0) & !nizGore(registar12, 0)){
								aktivnost1 = 0;
								nastaviG = 0;	
							}
							//ako ima aktivnih u smjeru pream dolje ispod trenutnog kata a nema nikakvih u smjeru prema gore, onda se mjenja smjer
							if(nizDolje(registar12, kat) & !nizGore(registar11, kat)){
								aktivnost1 = 2;
								naredba.naredba = IDI_DOLJE;
								liftNaredba1();
							}
							//ako nema aktivnih u smjeru prema dolje od trenutnog ali ima u smjeru prema gore
							if(nizDolje(registar11, kat) & !nizGore(registar12, 0)){
								aktivnost1 = 2;
								nastaviD = 1;
								naredba.naredba = IDI_DOLJE;
								liftNaredba1();
							}
							
							if(nizDolje(dolje1, kat)){
								naredba.naredba = IDI_DOLJE;
								aktivnost1 = 2;
								liftNaredba1();
								break;
							}
							
							break;
							
						case 2:
							
							if(nizDolje(dolje1, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba1();
								break;
							}
							
							if(nizDolje(registar12, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba1();
								}
								
								if(!nizDolje(registar12, kat) & nizDolje(registar11, kat)){
									naredba.naredba = IDI_DOLJE;
									liftNaredba1();
									nastaviD = 1;
								}
								
								if(!nizGore(registar12, 0) & !nizGore(registar11, 0)){
									aktivnost1 = 0;
									nastaviD = 0;
								}
								
								if(nizGore(registar11, kat) & !nizDolje(registar12, kat)){
									aktivnost1 = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba1();
								}
								
								if(nizGore(registar12, kat) & !nizGore(registar11, 0)){
									aktivnost1 = 1;
									nastaviG = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba1();
								}
								
								if(nizGore(gore1, kat)){
									naredba.naredba = IDI_GORE;
									aktivnost1 = 1;
									liftNaredba1();
									break;
								}
								
							break;
						}
					}
				}
				//Lift se giba gore
				if(lift_status1.stanja == GORE && lift_status1.cetvrtina == 2){	//primjer treba stat na 3.kat zna�i za 2.kat i 1/cetvrt mogu javit da stane
					int kat = lift_status1.kat;
						kat++;
					if(gore1[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba1();
					}
					
					if(registar11[kat] == 1 && nastaviG == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba1();
					}
					if(registar12[kat] == 1 && nastaviG == 1){
						if(najveci(registar12, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba1();
						}
					}
					
					
					
				}
				//Lift se giba dolje
				if(lift_status1.stanja == DOLJE && lift_status1.cetvrtina == 2){
					int kat = lift_status1.kat;
					
					if(dolje1[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba1();
					}
					
					if(registar12[kat] == 1 && nastaviD == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba1();
					}
					if(registar11[kat] == 1 && nastaviD == 1){
						if(najmanji(registar11, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba1();
						}
					}
					
				}
			lift_status1 = null;
			}//Kraj upravljanja
			
			
			
			
			
			
			
			if(lift_status2 != null){//Upravljanje liftom2
				if(lift_status2.stanja != STOJI_PRISILNO)
				status2 = lift_status2;
				Potvrda pot = new Potvrda();
				pot.id_poruke = id_status2;
				salji_potvrdu(LIFT2_PORT, pot);
				
				//Lift stoji i vrata su otvorena, vrata treba zatvoriti nakon isteka vremena
				if(lift_status2.stanja == STOJI && lift_status2.vrata == OTVORENA){
					brojanje2 = 1;
					cal = Calendar.getInstance();
					vrijeme21 = new Time(cal.getTimeInMillis());
					prvi2 = 1; //ozna�ava da je lift ve� bio u stanju zatvorenih vrata (pri stajanju na kat)
				}
				//Lift stoji i vrata su zatvorena, zadaje se smjer gibanja lifta ovisno o aktivnosti ili se otvaraju vrata
				//ako je tek stao na taj kat - onda se bri�e kat iz registra
				if(lift_status2.stanja == STOJI && lift_status2.vrata == ZATVORENA){
					//1. ulazak zaustavljen lift
					if(prvi2 == 0){
						naredba.naredba = OTVORI;
						liftNaredba2();
						int kat = lift_status2.kat; 
						switch (aktivnost2) {
						
						case 1:
							if(registar21[kat] == 1 || gore2[kat] == 1){
								registar21[kat] = 0;
								gore2[kat] = 0;
								gasiLft2(kat);
								gasiVanjske(kat*10+1);
							}
							
							if(nastaviG2 == 1 && registar22[kat] == 1){
								registar22[kat] = 0;
								gore2[kat] = 0;
								gasiLft2(kat);
								gasiVanjske(kat*10);
							}
							
							break;
							
						case 2:
													
							if(registar22[kat] == 1 || dolje2[kat] == 1){
								registar22[kat] = 0;
								dolje2[kat] = 0;
								gasiLft2(kat);
								gasiVanjske(kat*10);
							}
							
							if(nastaviD2 == 1 && registar21[kat] == 1){
								registar21[kat] = 0;
								dolje2[kat] = 0;
								gasiLft2(kat);
								gasiVanjske(kat*10+1);
							}
							break;
						}
					}
				
					//2. ulazak vrata bila otvorena te se zatvorila - ovdje se provjerava treba li pre�i u aktivnost miruje
					int kat = lift_status2.kat;
					if(prvi2 == 1){
						prvi2 = 0;
						nastaviG2 = 0;
						nastaviD2 = 0;
						switch (aktivnost2) {
						case 0:
							
							prvi2 = 1;
							break;
							
						case 1:
							if(nizGore(gore2, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba2();
								break;
							}
							
							//ako ima aktivnih katova iznad trenutnog u registru za gore
							if(nizGore(registar21, kat)){
							naredba.naredba = IDI_GORE;
							liftNaredba2();
							}
							//ako nema aktivnih u smjeru prema gore ali ima aktivnih u smjeru prema dolje iznad trenutnog kata
							if(!nizGore(registar21, kat) & nizGore(registar22, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba2();
								nastaviG2 = 1;
							}
							//ako nema aktivnih uop�e
							if(!nizGore(registar21, 0) & !nizGore(registar22, 0)){
								aktivnost2 = 0;
								nastaviG2 = 0;	
							}
							//ako ima aktivnih u smjeru pream dolje ispod trenutnog kata a nema nikakvih u smjeru prema gore, onda se mjenja smjer
							if(nizDolje(registar22, kat) & !nizGore(registar21, kat)){
								aktivnost2 = 2;
								naredba.naredba = IDI_DOLJE;
								liftNaredba2();
							}
							//ako nema aktivnih u smjeru prema dolje od trenutnog ali ima u smjeru prema gore
							if(nizDolje(registar21, kat) & !nizGore(registar22, 0)){
								aktivnost2 = 2;
								nastaviD2 = 1;
								naredba.naredba = IDI_DOLJE;
								liftNaredba2();
							}
							
							if(nizDolje(dolje2, kat)){
								naredba.naredba = IDI_DOLJE;
								aktivnost2 = 2;
								liftNaredba2();
								break;
							}
							
							break;
							
						case 2:
							
							if(nizDolje(dolje2, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba2();
								break;
							}
							
							if(nizDolje(registar22, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba2();
								}
								
								if(!nizDolje(registar22, kat) & nizDolje(registar21, kat)){
									naredba.naredba = IDI_DOLJE;
									liftNaredba2();
									nastaviD2 = 1;
								}
								
								if(!nizGore(registar22, 0) & !nizGore(registar21, 0)){
									aktivnost2 = 0;
									nastaviD2 = 0;
								}
								
								if(nizGore(registar21, kat) & !nizDolje(registar22, kat)){
									aktivnost2 = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba2();
								}
								
								if(nizGore(registar22, kat) & !nizGore(registar21, 0)){
									aktivnost2 = 1;
									nastaviG2 = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba2();
								}
								
								if(nizGore(gore2, kat)){
									naredba.naredba = IDI_GORE;
									aktivnost2 = 1;
									liftNaredba2();
									break;
								}
								
							break;
						}
					}
				}
				//Lift se giba gore
				if(lift_status2.stanja == GORE && lift_status2.cetvrtina == 2){	//primjer treba stat na 3.kat zna�i za 2.kat i 1/cetvrt mogu javit da stane
					int kat = lift_status2.kat;
						kat++;
					if(gore2[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba2();
					}
					
					if(registar21[kat] == 1 && nastaviG2 == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba2();
					}
					if(registar22[kat] == 1 && nastaviG2 == 1){
						if(najveci(registar22, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba2();
						}
					}
					
					
					
				}
				//Lift se giba dolje
				if(lift_status2.stanja == DOLJE && lift_status2.cetvrtina == 2){
					int kat = lift_status2.kat;
					
					if(dolje2[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba2();
					}
					
					if(registar22[kat] == 1 && nastaviD2 == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba2();
					}
					if(registar21[kat] == 1 && nastaviD2 == 1){
						if(najmanji(registar21, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba2();
						}
					}
					
				}
			lift_status2 = null;
			}//Kraj upravljanja2
			
			
			
			
			if(lift_status3 != null){//Upravljanje liftom3
				if(lift_status3.stanja != STOJI_PRISILNO)
				status3 = lift_status3;
				Potvrda pot = new Potvrda();
				pot.id_poruke = id_status3;
				salji_potvrdu(LIFT3_PORT, pot);
				
				//Lift stoji i vrata su otvorena, vrata treba zatvoriti nakon isteka vremena
				if(lift_status3.stanja == STOJI && lift_status3.vrata == OTVORENA){
					brojanje3 = 1;
					cal = Calendar.getInstance();
					vrijeme31 = new Time(cal.getTimeInMillis());
					prvi3 = 1; //ozna�ava da je lift ve� bio u stanju zatvorenih vrata (pri stajanju na kat)
				}
				//Lift stoji i vrata su zatvorena, zadaje se smjer gibanja lifta ovisno o aktivnosti ili se otvaraju vrata
				//ako je tek stao na taj kat - onda se bri�e kat iz registra
				if(lift_status3.stanja == STOJI && lift_status3.vrata == ZATVORENA){
					//1. ulazak zaustavljen lift
					if(prvi3 == 0){
						naredba.naredba = OTVORI;
						liftNaredba3();
						int kat = lift_status3.kat; 
						switch (aktivnost3) {
						
						case 1:
							if(registar31[kat] == 1 || gore3[kat] == 1){
								registar31[kat] = 0;
								gore3[kat] = 0;
								gasiLft3(kat);
								gasiVanjske(kat*10+1);
							}
							
							if(nastaviG3 == 1 && registar32[kat] == 1){
								registar32[kat] = 0;
								gore3[kat] = 0;
								gasiLft3(kat);
								gasiVanjske(kat*10);
							}
							
							break;
							
						case 2:
													
							if(registar32[kat] == 1 || dolje3[kat] == 1){
								registar32[kat] = 0;
								dolje3[kat] = 0;
								gasiLft3(kat);
								gasiVanjske(kat*10);
							}
							
							if(nastaviD3 == 1 && registar31[kat] == 1){
								registar31[kat] = 0;
								dolje3[kat] = 0;
								gasiLft3(kat);
								gasiVanjske(kat*10+1);
							}
							break;
						}
					}
				
					//2. ulazak vrata bila otvorena te se zatvorila - ovdje se provjerava treba li pre�i u aktivnost miruje
					int kat = lift_status3.kat;
					if(prvi3 == 1){
						prvi3 = 0;
						nastaviG3 = 0;
						nastaviD3 = 0;
						switch (aktivnost3) {
						case 0:
							
							prvi3 = 1;
							break;
							
						case 1:
							if(nizGore(gore3, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba3();
								break;
							}
							
							//ako ima aktivnih katova iznad trenutnog u registru za gore
							if(nizGore(registar31, kat)){
							naredba.naredba = IDI_GORE;
							liftNaredba3();
							}
							//ako nema aktivnih u smjeru prema gore ali ima aktivnih u smjeru prema dolje iznad trenutnog kata
							if(!nizGore(registar31, kat) & nizGore(registar32, kat)){
								naredba.naredba = IDI_GORE;
								liftNaredba3();
								nastaviG3 = 1;
							}
							//ako nema aktivnih uop�e
							if(!nizGore(registar31, 0) & !nizGore(registar32, 0)){
								aktivnost3 = 0;
								nastaviG3 = 0;	
							}
							//ako ima aktivnih u smjeru pream dolje ispod trenutnog kata a nema nikakvih u smjeru prema gore, onda se mjenja smjer
							if(nizDolje(registar32, kat) & !nizGore(registar31, kat)){
								aktivnost3 = 2;
								naredba.naredba = IDI_DOLJE;
								liftNaredba3();
							}
							//ako nema aktivnih u smjeru prema dolje od trenutnog ali ima u smjeru prema gore
							if(nizDolje(registar31, kat) & !nizGore(registar32, 0)){
								aktivnost3 = 2;
								nastaviD3 = 1;
								naredba.naredba = IDI_DOLJE;
								liftNaredba3();
							}
							
							if(nizDolje(dolje3, kat)){
								naredba.naredba = IDI_DOLJE;
								aktivnost3 = 2;
								liftNaredba3();
								break;
							}
							
							break;
							
						case 2:
							
							if(nizDolje(dolje3, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba3();
								break;
							}
							
							if(nizDolje(registar32, kat)){
								naredba.naredba = IDI_DOLJE;
								liftNaredba3();
								}
								
								if(!nizDolje(registar32, kat) & nizDolje(registar31, kat)){
									naredba.naredba = IDI_DOLJE;
									liftNaredba3();
									nastaviD3 = 1;
								}
								
								if(!nizGore(registar32, 0) & !nizGore(registar31, 0)){
									aktivnost3 = 0;
									nastaviD3 = 0;
								}
								
								if(nizGore(registar31, kat) & !nizDolje(registar32, kat)){
									aktivnost3 = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba3();
								}
								
								if(nizGore(registar32, kat) & !nizGore(registar31, 0)){
									aktivnost3 = 1;
									nastaviG3 = 1;
									naredba.naredba = IDI_GORE;
									liftNaredba3();
								}
								
								if(nizGore(gore3, kat)){
									naredba.naredba = IDI_GORE;
									aktivnost3 = 1;
									liftNaredba1();
									break;
								}
								
							break;
						}
					}
				}
				//Lift se giba gore
				if(lift_status3.stanja == GORE && lift_status3.cetvrtina == 2){	//primjer treba stat na 3.kat zna�i za 2.kat i 1/cetvrt mogu javit da stane
					int kat = lift_status3.kat;
						kat++;
					if(gore3[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba3();
					}
					
					if(registar31[kat] == 1 && nastaviG3 == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba3();
					}
					if(registar32[kat] == 1 && nastaviG3 == 1){
						if(najveci(registar32, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba3();
						}
					}
					
					
					
				}
				//Lift se giba dolje
				if(lift_status3.stanja == DOLJE && lift_status3.cetvrtina == 2){
					int kat = lift_status3.kat;
					
					if(dolje3[kat] == 1){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba3();
					}
					
					if(registar32[kat] == 1 && nastaviD3 == 0){
						naredba.naredba = STANI_NA_IDUCEM;;
						liftNaredba3();
					}
					if(registar31[kat] == 1 && nastaviD3 == 1){
						if(najmanji(registar31, kat) == kat){
							naredba.naredba = STANI_NA_IDUCEM;;
							liftNaredba3();
						}
					}
					
				}
			lift_status3 = null;
			}//Kraj upravljanja3
			
			
			
			
			
			if(ponovo == 0){
				cal = Calendar.getInstance();
				vreme2 = new Time(cal.getTimeInMillis());
				if(vreme2.getTime() - vreme1.getTime() > 6)
					ponovo = 1;
			}
			ponovo();
			//System.out.println("aktivnost = "+ aktivnost1 + " nG "+ nastaviG +" nD " + nastaviD + " zabrana " +zabrana);
			
		}//kraj while petlje
	}//kraj run-a
	
	
	/**
	 * nadalje su prikazane sve funkcije koje se koriste
	 */
	
	//funkcija za provjeru jeli niz ima elemenata koji su u 1 od kata prema gore
	private boolean nizGore(int[] b, int k){
		for(int i = k; i < b.length; i++){
			if(b[i] == 1)
				return true;
		}
		return false;
	}
	
	private boolean nizDolje(int[] b, int k){
		for(int i = k; i >= 0; i--){
			if(b[i] == 1)
				return true;
		}
		return false;
	}
	
	private int najveci(int[] b, int k){
		int broj = -1;
		for(int i = k; i < b.length; i++){
			if(b[i] == 1)
				broj = i;
		}
		return broj;
	}
	
	private int najmanji(int[] b, int k){
		int broj = -1;
		for(int i = k; i >= 0; i--){
			if(b[i] == 1)
				broj = i;
		}
		return broj;
	}
	
	
	private void gasiVanjske(int tipka){
		naredba.naredba = PRIKAZI;
		naredba.prikaz = TIPKA_UGASI;
		naredba.n = tipka;
		naredba_tipke();
	}
	
	private void naredba_tipke() {
		salji_naredba(TIPKE_PORT, naredba, ++id);
		dodaj(TIPKE_PORT);
	}
	
	//metode za liftove
	
	private void liftNaredba1(){
		za_lift1.add(new Naredba(naredba.naredba, naredba.prikaz, naredba.n));
	}
	
	private void gasiLft1(int tipka){
		naredba.naredba = PRIKAZI;
		naredba.prikaz = TIPKA_UGASI;
		naredba.n = tipka;
		liftNaredba1();
	}
	
	private void naredba_lift1() {
		salji_naredba(LIFT_PORT, naredba, ++id);
		dodaj(LIFT_PORT);		
	}
	
	
	private void liftNaredba2(){
		za_lift2.add(new Naredba(naredba.naredba, naredba.prikaz, naredba.n));
	}
	
	private void gasiLft2(int tipka){
		naredba.naredba = PRIKAZI;
		naredba.prikaz = TIPKA_UGASI;
		naredba.n = tipka;
		liftNaredba2();
	}
	
	private void naredba_lift2() {
		salji_naredba(LIFT2_PORT, naredba, ++id);
		dodaj(LIFT2_PORT);		
	}
	
	
	private void liftNaredba3(){
		za_lift3.add(new Naredba(naredba.naredba, naredba.prikaz, naredba.n));
	}
	
	private void gasiLft3(int tipka){
		naredba.naredba = PRIKAZI;
		naredba.prikaz = TIPKA_UGASI;
		naredba.n = tipka;
		liftNaredba3();
	}
	
	private void naredba_lift3() {
		salji_naredba(LIFT3_PORT, naredba, ++id);
		dodaj(LIFT3_PORT);		
	}
	
	//zajedni�ko
	
	private void dodaj(int port) {
		Time v1;
		Calendar cal1;
		cal1 = Calendar.getInstance();
		v1 = new Time(cal1.getTimeInMillis());
		//System.out.println("dodana naredba na spremnik id = " + id);
		Lista_naredbi.add(new Spremnik(v1, id, port, naredba.naredba, naredba.prikaz, naredba.n));
	}

	/**
	 * 
	 * @param pot
	 * Provjerava jeli potvrda koja je stigla odgovor na naredbu koja je stavljen au listu za slanje
	 * ako je naredba se uklanja s liste
	 */
	private void provjeri(Potvrda pot){
		Spremnik Temp = new Spremnik();
		for (int h = 0; h < Lista_naredbi.size(); h++) {
			Temp = Lista_naredbi.get(h);
			if(Temp.id_naredbe == pot.id_poruke){
				Lista_naredbi.remove(h);
				//System.out.println("\nStigla potvrda za naredbu! "+pot.id_poruke +" Uklonjena naredba sa Spremnika");
				break;	//nema potrebe provjeravat dalje
			}
		}
	}
	
	private void ponovo(){
		//provjera ima li naredbe koja se treba slati
		if(!Lista_naredbi.isEmpty())
		{
		Spremnik Temp = Lista_naredbi.getFirst();
		int id_naredbe;
		int port;
		Naredba nar = new Naredba();
		//provjera vremena
		Time v2, v1;
		Calendar cal2;
		cal2 = Calendar.getInstance();
		v2 = new Time(cal2.getTimeInMillis());
		v1 = Temp.v1;
		if(v2.getTime() - v1.getTime() > 30){
		throw new IllegalStateException("Potvrda za naredbu nije stigla unutar zadanog vremeana");
		}
		if(v2.getTime() - v1.getTime() > 5 && ponovo == 1)
		{	ponovo = 0;
			//vrijeme slanja prethodne
			cal = Calendar.getInstance();
			vreme1 = new Time(cal.getTimeInMillis());
			id_naredbe = Temp.id_naredbe;
			port = Temp.odrediste;
			nar.n = Temp.n;
			nar.naredba = Temp.naredba;
			nar.prikaz = Temp.prikaz;
			salji_naredba(port, nar, id_naredbe);
			//System.out.println("Ponovno se �alje naredba s id-om "+id_naredbe);
		}

		}
	}
	
	static void salji_naredba(int gdje, Naredba naredba, int id_naredbe){
		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = id_naredbe;
		nova_poruka1.tip_poruke = NAREDBA;
		nova_poruka1.sadrzaj = naredba;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();
			int number = buf.length;
			byte[] data = new byte[4];
			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}
	
	static void salji_potvrdu(int gdje, Potvrda potvrda){
		id++;
		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = id;
		nova_poruka1.tip_poruke = POTVRDA;
		nova_poruka1.sadrzaj = potvrda;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();
			int number = buf.length;
			byte[] data = new byte[4];
			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
			//System.out.println("poslana potvrda ");
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}
	
}



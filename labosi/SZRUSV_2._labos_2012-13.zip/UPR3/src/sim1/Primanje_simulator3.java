package sim1;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import strukture.Lift_status;
import strukture.Poruka;
import strukture.Potvrda;
import strukture.Tipka;

public class Primanje_simulator3 implements Runnable, Header { // sa runnable je definirana dretva

	private Thread t;
	private byte[] primljeni_podaci;
	private DatagramSocket s;
	
	
	public Primanje_simulator3(DatagramSocket socket) {
		this.s = socket;
		t = new Thread(this); // pokretanje nove dretve u program se prenosi
								// socket
		t.start();
	}

	@Override
	public void run() {
		System.out.println("Primanje radi!");
		DatagramPacket primljeni_paket;

		while (true) { // petlja koja prima poruke
			primljeni_podaci = new byte[2048];
			primljeni_paket = new DatagramPacket(primljeni_podaci,
					primljeni_podaci.length);
			try {
				s.receive(primljeni_paket);
				ByteArrayInputStream baos = new ByteArrayInputStream(primljeni_podaci);
				ObjectInputStream oos = new ObjectInputStream(baos);
				Poruka primljena_poruka = (Poruka) oos.readObject();
				//System.out.println("\nsimulator prima poruku: " + primljena_poruka.tip_poruke + " id " + primljena_poruka.id_poruke);
				
				if (primljena_poruka != null) {
					switch (primljena_poruka.posiljatelj) {
					case LIFT1:
						switch (primljena_poruka.tip_poruke) {
						case LIFT_STATUS:
							logika_sim3.lift_status1 = (Lift_status) primljena_poruka.sadrzaj;
							logika_sim3.id_status1 = primljena_poruka.id_poruke;
							break;

						case TIPKA:
							logika_sim3.tipkeLift1 = (Tipka) primljena_poruka.sadrzaj;
							//Tipka tip1 = (Tipka) primljena_poruka.sadrzaj;
							//logika_sim3.lista_tipke.add(new Tipka(tip1.id_tipke, tip1.id_posiljatelja));
							break;

						case POTVRDA:
							logika_sim3.potvrda = (Potvrda) primljena_poruka.sadrzaj;
							//TODO ubacivanje u vezanu listu potvrde
							break;
						}
						break;
					
						
					case LIFT2:
						switch (primljena_poruka.tip_poruke) {
						case LIFT_STATUS:
							logika_sim3.lift_status2 = (Lift_status) primljena_poruka.sadrzaj;
							logika_sim3.id_status2 = primljena_poruka.id_poruke;
							break;

						case TIPKA:
							logika_sim3.tipkeLift2 = (Tipka) primljena_poruka.sadrzaj;
							//Tipka tip1 = (Tipka) primljena_poruka.sadrzaj;
							//logika_sim3.lista_tipke.add(new Tipka(tip1.id_tipke, tip1.id_posiljatelja));
							break;

						case POTVRDA:
							logika_sim3.potvrda2 = (Potvrda) primljena_poruka.sadrzaj;
							//TODO ubacivanje u vezanu listu potvrde
							break;
						}
						break;	
						
						
					case LIFT3:
						switch (primljena_poruka.tip_poruke) {
						case LIFT_STATUS:
							logika_sim3.lift_status3 = (Lift_status) primljena_poruka.sadrzaj;
							logika_sim3.id_status3 = primljena_poruka.id_poruke;
							break;

						case TIPKA:
							logika_sim3.tipkeLift3 = (Tipka) primljena_poruka.sadrzaj;
							//Tipka tip1 = (Tipka) primljena_poruka.sadrzaj;
							//logika_sim3.lista_tipke.add(new Tipka(tip1.id_tipke, tip1.id_posiljatelja));
							break;

						case POTVRDA:
							logika_sim3.potvrda3 = (Potvrda) primljena_poruka.sadrzaj;
							//TODO ubacivanje u vezanu listu potvrde
							break;
						}
						break;

					case TIPKE:
						switch (primljena_poruka.tip_poruke) {
						case TIPKA:
							logika_sim3.tipkeVanjske = (Tipka) primljena_poruka.sadrzaj;
							//Tipka tip = (Tipka) primljena_poruka.sadrzaj;
							//logika_sim3.lista_tipkeV.add(new Tipka(tip.id_tipke, tip.id_posiljatelja)); 
							break;

						case POTVRDA:
							logika_sim3.potvrdaTipke = (Potvrda) primljena_poruka.sadrzaj;
							break;
						}
						break;
					}

				}
				//kraj
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}


		}

	}

}

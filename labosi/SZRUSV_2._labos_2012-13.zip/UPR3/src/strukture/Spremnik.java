package strukture;

import java.io.Serializable;
import java.sql.Time;

public class Spremnik implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1784554745151L;
	public Time v1;
	public int id_naredbe;
	public int odrediste;
	public int naredba;
	public int prikaz;
	public int n;
	
	public Spremnik(){
		
	}

	public Spremnik(Time v1, int id_naredbe, int odrediste, int naredba, int prikaz, int n){
		this.v1 = v1;
		this.id_naredbe = id_naredbe;
		this.odrediste = odrediste;
		this.naredba = naredba;
		this.prikaz = prikaz;
		this.n = n;
	}

}

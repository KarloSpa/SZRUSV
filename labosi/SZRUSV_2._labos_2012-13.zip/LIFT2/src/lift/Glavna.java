package lift;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;


//import strukture.Naredba;
import strukture.Poruka;
import strukture.Tipka;
/**
 * Njegova uloga je obra�ivanje doga�aja koji dolaze s tipkovnice
 * Svaki put kad se stisne neka tipka �elje se poruka tipka UPR-u
 */
//
public class Glavna implements Header {

	static DatagramSocket s; // s je socket
	static Scanner input;
	static InetAddress localhost = null; // ona adresa od udp-a
	
	public static int id = 0;
	
	
	
	public static void main(String[] args) { // odavde po�inje main
		/**
		 * Sa try i catch se osigurava da u slu�aju iznimke program radi dobro
		 * u ovom slu�aju iznimka sa socketom
		 */
		try {
			localhost = InetAddress.getLocalHost();
			s = new DatagramSocket(LIFT2_PORT);
		} catch (SocketException e) { 
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		/**
		 * Pokre�u se dretve za Logiku lifta i primanje poruka
		 */
		new Logika_lifta();
		new Primanje(s);
		input = new Scanner(System.in);

		System.out.println("Lift2 radi i ceka poruke:\n");

		while (true) {
			String input_iz_tipkovnice = input.next();
			
				//s tipkovnice se unosi jedan znak
				char slovo = input_iz_tipkovnice.charAt(0);
				
				Tipka tipka = new Tipka();
				switch ((int) slovo) {
				case (int) '0':
					tipka.id_tipke = 0;
					break;
					
				case (int) '1':
					tipka.id_tipke = 1;
					break;

				case (int) '2':
					tipka.id_tipke = 2;
					break;

				case (int) '3':
					tipka.id_tipke = 3;
					break;

				case (int) '4':
					tipka.id_tipke = 4;
					break;

				case (int) '5':
					tipka.id_tipke = 5;
					break;

				case (int) '6':
					tipka.id_tipke = 6;
					break;

				case (int) '7':
					tipka.id_tipke = 7;
					break;

				case (int) '8':
					tipka.id_tipke = 8;
					break;

				case (int) '9':
					tipka.id_tipke = 9;
					break;

				case (int) 'k':
					tipka.id_tipke = KRENI;
					break;

				case (int) 's':
					tipka.id_tipke = STANI;
					break;
				}
			
				salji_tipka(UPRAVLJACKI_PORT, tipka);	//jedino pozivanje slanja u ovom programu
				System.out.println("saljem tipka " + tipka.id_tipke);
				/**
				 * 	Na odgovor o poslanoj tipci se ne �eka
				 * ve� se o�ekuje primanje poruke o aktivaciji/ga�enju tipke
				 *  
				 */
	
		}

	}
	

		
static void salji_tipka(int gdje, Tipka tipka){
		id++;
		Poruka nova_poruka1 = new Poruka();
		nova_poruka1.id_poruke = id;
		nova_poruka1.tip_poruke = TIPKA;
		nova_poruka1.sadrzaj = tipka;
		nova_poruka1.posiljatelj = LIFT2;
		//kop
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(baos);
		} catch (IOException e1) {
			e1.printStackTrace();
		}//kop
		//kop
		try {
			oos.writeObject(nova_poruka1);
			oos.flush();
			// get the byte array of the object
			byte[] buf = baos.toByteArray();

			int number = buf.length;
			byte[] data = new byte[4];

			// int -> byte[]
			for (int i = 0; i < 4; ++i) {
				int shift = i << 3; // i * 8
				data[3 - i] = (byte) ((number & (0xff << shift)) >>> shift);
			}
			Glavna.udpSend(buf, gdje);
		} catch (IOException e) {
			e.printStackTrace();
		}//kop
		
	}
	
public static void udpSend(byte[] sendData, int primatelj) { 

	DatagramPacket paket_za_slanje = new DatagramPacket(sendData,
			sendData.length, localhost, primatelj);
	try {
		s.send(paket_za_slanje);
	} catch (IOException e) {
		e.printStackTrace();
	}
}

}

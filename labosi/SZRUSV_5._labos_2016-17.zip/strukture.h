#ifndef SRSV_LAB5_STRUKTURE_H
#define SRSV_LAB5_STRUKTURE_H

#define MQ_ID 112
#define MAX_SIZE 26
#define MSG_TYPE 2
#define WORK_TIME 10
#define MAX_JOBS 100

typedef struct {
    long mtype;
    char mtext[MAX_SIZE];
} my_msgbuf;

typedef struct {
    long last_id;
    pthread_mutex_t obj;
} mmessage_id;

typedef struct {
    char name[MAX_SIZE];
    long id;
} mjob_desc;

typedef struct {
    long id;
    long execute_time;
    long jobs[MAX_JOBS];

} mmessage;

char *envName = "SRSV_LAB5";
static long numOfIterations = WORK_TIME;

void calculateNumOfIterations() {
    long i, j;
    struct timespec start, stop;
    double total = 0;
    while (total < 1.0) {
        numOfIterations *= 2;

        if (clock_gettime(CLOCK_MONOTONIC, &start) == -1) {
            exit(EXIT_FAILURE);
        }
        for (i = 0; i < numOfIterations; i++) {
            asm volatile ("":: :"memory");
        }
        if (clock_gettime(CLOCK_MONOTONIC, &stop) == -1) {
            exit(EXIT_FAILURE);
        }

        total += (stop.tv_sec - start.tv_sec) + (stop.tv_nsec - start.tv_nsec) / 1000000000.0;
    }
    numOfIterations = numOfIterations/total*2;
}

void waitSecond() {
    long j;
    if (numOfIterations == WORK_TIME) {
        calculateNumOfIterations();
    }
    for (j = 0; j < numOfIterations; ++j) {
        asm volatile ("":: :"memory");
    }
}

#endif

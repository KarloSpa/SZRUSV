#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <mqueue.h>
#include <errno.h>
#include <sys/msg.h>
#include "list.h"
#include "strukture.h"


char volatile stopEverything = 0;
static sem_t waitSem, sem;
static volatile int numOfJobs = 0;
static volatile long workTime = 0;
list *jobList;
int msq_id;


void stopHandler(int signal) {
    printf("Posluzitelj: Funkcija ciscenja...\n");
    stopEverything = 1;
    sem_post(&waitSem);
    delete_list(jobList);
    if (msgctl(msq_id, IPC_RMID, NULL) == -1) {
        fprintf(stderr, "Poslužitelj: msqctl %s!\n", strerror(errno));
        exit(1);
    }
    exit(0);
}

void parseReceivedMsg(char *msg, char *path, long *id);

void *dretva_radna(void *indexV) {
    int *n = indexV;
    char *taskData = NULL;
    mjob_desc jobDesc;
    int mem_id, j;
    long i;
    mmessage *task = NULL;
    printf("Radna dretva %d: startam\n", *n);
   sem_wait(&waitSem);

    while (1) {
        sem_wait(&sem);
        taskData = get_element(jobList);
        printf("Radna dretva %d: Dohvaćam zadatak %s\n", *n, taskData);
        sem_post(&sem);

        if (taskData != NULL) {
            printf("Radna dretva %d: Dohvaćam podatke zadatka %s\n", *n, taskData);
            parseReceivedMsg(taskData, jobDesc.name, &jobDesc.id);
            if((mem_id = shm_open(taskData, O_CREAT | O_RDWR, 00600)) == -1){
                fprintf(stderr, "Radna dretva %d: shm_open %s\n", *n, strerror(errno));
                exit(1);
            }
            if (ftruncate(mem_id, sizeof(mmessage)) == -1) {
                fprintf(stderr, "Radna dretva %d: ftruncate %s\n", *n, strerror(errno));
                exit(1);
            }
            printf("Radna dretva %d: Podaci dohvaćeni \n", *n);
            task = mmap(NULL, sizeof(mmessage), PROT_READ, MAP_SHARED, mem_id, 0);
            if (task == (void *) -1) {
                fprintf(stderr, "Radna dretva %d: mmap %s\n", *n, strerror(errno));
                exit(1);
            }
            close(mem_id);


            for (i = 0; i < task->execute_time; ++i) {
                printf("Radna dretva %d: id:%li obrada podatka: %li (%li/%li)\n", *n, i,task->jobs[i],  i + 1,
                       task->execute_time);
               waitSecond();
            }

            munmap(task, sizeof(mmessage));
            shm_unlink(taskData);
            free(taskData);
            --numOfJobs;
            printf("Radna dretva %d:: gotova s polsim\n", *n);
        } else if (stopEverything) {
            break;
        } else {
            printf("Radna dretva %d:: nema poslova, čekam\n", *n);
        }

        if (!stopEverything) {
            sem_wait(&waitSem);
        }
    }
    return indexV;

}

int main(int argc, char *argv[]) {
    int N, i, *threadIndexes = NULL;
    ssize_t rcvVal;
    pthread_attr_t attr;
    struct sched_param prio;
    pthread_t *tid = NULL;
    struct timespec tms, lastMsgTM;
    long M;
    mjob_desc jobDesc;
    my_msgbuf buf;

    //dohvati i provjeri argumente
    if (argc != 3) {
        fprintf(stderr, "Poslužitelj: neispravan broj argumenata %d!\n", argc);
        return -1;
    }
    N = atoi(argv[1]);
    if (N <= 0) {
        fprintf(stderr, "Poslužitelj: neispravan N %d\n", N);
        return -1;
    }
    M = atoi(argv[2]);
    if (M <= 0) {
        printf("Poslužitelj: neispravan M %li\n", M);
        return -1;
    }

    printf("Posluzitelj startam...\n");
    //postavi funkciju koja ce se pozvati prije terminiranja
    signal(SIGQUIT, stopHandler);
    signal(SIGINT, stopHandler);
    signal(SIGTERM, stopHandler);

    //postavi prioritet za ovu dretvu pošto će ona biti dretva za zaprimanje
    prio.sched_priority = 60;
    if (pthread_setschedparam(pthread_self(), SCHED_RR, &prio)) {
        fprintf(stderr, "Posluzitelj: greska prilikom postavljanja sched-a, da li imam admin prava?\n");
        exit(1);
    }

    //napravi listu u koju ce se spremati poslovi
    jobList = create_list();

    //alociraj array za tidove
    tid = (pthread_t *) malloc(sizeof(pthread_t) * N);
    threadIndexes = (int *) malloc(sizeof(int) * N);

    //napravi semafor
    sem_init(&sem, 0, 1);
    sem_init(&waitSem, 0, N);

    //napravi nove dretve i podesi im prioritet
    pthread_attr_init(&attr);
    pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
    pthread_attr_setschedpolicy(&attr, SCHED_RR);
    prio.sched_priority = 40;
    pthread_attr_setschedparam(&attr, &prio);
    for (i = 0; i < N; ++i) {
        threadIndexes[i] = i + 1;
        if (pthread_create(&tid[i], &attr, dretva_radna, (void *) &threadIndexes[i])) {
            fprintf(stderr, "Posluzitelj: greska prilikom kreiranja dretve %d %s\n", i, strerror(errno));
            exit(1);
        }
    }

    //napravi mq
    if ((msq_id = msgget(MQ_ID, 0600 | IPC_CREAT)) == -1) {
        fprintf(stderr, "Posluzitelj: ne mogu otvoriti red poruka %s\n", strerror(errno));
        exit(1);
    }

    //dretva koja zaprima
    while (1) {
        if (stopEverything) {
            break;
        }
        clock_gettime(CLOCK_REALTIME, &tms);
        printf("Dretva zaprima: trenutno_vrijeme %li vrijeme_cekanja %li\n", tms.tv_sec,
               lastMsgTM.tv_sec);

        rcvVal = msgrcv(msq_id, (struct msgbuf *) &buf, sizeof(buf) - sizeof(long), MSG_TYPE, IPC_NOWAIT);
        if (rcvVal > 0) {//pogledaj da li ima koja nova poruka
            //postoji poruka, izračunaj vrijeme, dodaj u listu
            parseReceivedMsg(buf.mtext, jobDesc.name, &jobDesc.id);
            workTime += jobDesc.id;
            sem_wait(&sem);
            jobList = insert_element(jobList, &buf.mtext, sizeof(buf.mtext));
            ++numOfJobs;
            sem_post(&sem);
            clock_gettime(CLOCK_REALTIME, &lastMsgTM);
            printf("Dretva zaprima: dobivena poruka: %s %li\n", jobDesc.name, jobDesc.id);
        } else if (rcvVal < 0 && errno != ENOMSG) {
            fprintf(stderr, "Dretva zaprima: ne mogu otvoriti red poruka %s\n", strerror(errno));
        }

        if ((workTime >= M && numOfJobs >= N) || (((tms.tv_sec - lastMsgTM.tv_sec) > 30)) && numOfJobs > 0) {
            printf("Dretva zaprima: budim radne dretve\n");
            sem_post(&waitSem);
        }
        waitSecond();
    }

    for (i = 0; i < N; ++i) {
        pthread_join(tid[i], NULL);
    }

    printf("Posluzitelj: zavrsavam...\n");

    free(tid);
    free(threadIndexes);
    return 0;
}

void parseReceivedMsg(char *msg, char *path, long *id) {
    char str[MAX_SIZE], *ptr;
    strcpy(str, msg);
    strtok_r(str, "-", &ptr);
    strcpy(path, str);
    *id = atol(ptr);
}
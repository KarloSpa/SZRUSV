#include <stdio.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <memory.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include "strukture.h"

long volatile lastMemId, maxTime = 20L;

mmessage make_task(long id, long maxTime);

long readLastIdInSharedMemory(char buffName[MAX_SIZE], long J);

void writeToSharedMem(char name[MAX_SIZE]);

int main(int argc, char *argv[]) {
    int J, i;
    char buffName[MAX_SIZE], *mq_msg;
    mmessage task;
    int msq_id;
    struct sched_param prio;
    my_msgbuf buf;

    printf("Generator: startam\n");
    if (argc < 2 || argc > 3) {
        fprintf(stderr, "Generator:neispravan broj argumenata %d\n", argc);
        exit(1);
    }
    J = atoi(argv[1]);
    if (argc == 3) {
        maxTime = atol(argv[2]);
    }

    if (J <= 0) {
        fprintf(stderr, "Generator:neispravan J %d\n", J);
        exit(1);
    }

    prio.sched_priority = 50;
    if (pthread_setschedparam(pthread_self(), SCHED_RR, &prio)) {
        fprintf(stderr, "Generator: greska prilikom postavljanja sched-a, da li imam admin prava?");
        exit(1);
    }

    //get buff name
    strcpy(buffName, getenv(envName));

    srand(time(NULL));

    lastMemId = readLastIdInSharedMemory(buffName, J);
    printf("Generator: Zadnji id:%li\nGenerator: Maksimalno vrijeme izvodenja:%li\n", lastMemId, maxTime);

    //create message queue
    if ((msq_id = msgget(MQ_ID, 0600 | IPC_CREAT)) == -1) {
        fprintf(stderr, "Generator: ne mogu stvoriti red poruka %s\n", strerror(errno));
        exit(1);
    }

    for (i = 0; i < J; ++i) {
        lastMemId++;
        mq_msg = (char *) malloc(sizeof(char) * MAX_SIZE);
        sprintf(mq_msg, "%s-%li", buffName, lastMemId);
        writeToSharedMem(mq_msg);
        memcpy(buf.mtext, mq_msg, strlen(mq_msg) + 1);
        buf.mtype = MSG_TYPE;
        printf("Generator: saljem zadatak\n");
        if (msgsnd(msq_id, (struct msgbuf *) &buf, strlen(mq_msg) + 1, 0)) {
            fprintf(stderr, "Generator: greska prilikom stavljanje poruke u red poruka %s\n", strerror(errno));
            exit(1);
        }
        free(mq_msg);
        waitSecond();
    }
    return 0;
}

void writeToSharedMem(char name[MAX_SIZE]) {
    mmessage *task;
    mmessage createdTask;
    int fdflags;
    long i;

    int fd = shm_open(name, O_CREAT | O_RDWR, 00600);
    if (fd == -1 || ftruncate(fd, sizeof(mmessage)) == -1) {
        fprintf(stderr, "Generator: Greska prilikom truncate:%s\n", strerror(errno));
        exit(1);
    }

    createdTask = make_task(lastMemId, maxTime);
    task = mmap(NULL, sizeof(mmessage), PROT_WRITE, MAP_SHARED, fd, 0);
    memcpy(task, &createdTask, sizeof(mmessage));
    printf("Generator: Novi task %li %li [", task->id, task->execute_time);
    for (i = 0; i < task->execute_time; ++i) {
        printf("%li ", task->jobs[i]);
    }
    printf("]\n");
    munmap(task, sizeof(mmessage));
    fdflags = fcntl(fd, F_GETFD);
    fdflags &= ~FD_CLOEXEC;
    fcntl(fd, F_SETFD, fdflags);
    close(fd);
}

mmessage make_task(long id, long maxTime) {
    long i = 0;
    char taskData[MAX_SIZE];
    mmessage task;
    task.execute_time = rand() % maxTime + 1;
    task.id = id;
    for (i = 0; i < task.execute_time; ++i) {
        task.jobs[i] = rand();
    }
    return task;
}

long readLastIdInSharedMemory(char buffName[MAX_SIZE], long J) {
    int fd;
    mmessage_id *memPtr;
    long id;

    printf("Generator: ime zajednickog prostora: %s\n", buffName);
    fd = shm_open(buffName, O_RDWR | O_CREAT, 00600);
    if (fd == -1) {
        fprintf(stderr, "Generator:Greska prilikom otvaranja:%s\n", strerror(errno));
        exit(1);
    }

    if (ftruncate(fd, sizeof(mmessage_id)) == -1) {
        fprintf(stderr, "Generator: Greska prilikom truncate:%s\n", strerror(errno));
        exit(1);
    }


    memPtr = mmap(0, sizeof(mmessage_id), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (memPtr == (void *) -1) {
        fprintf(stderr, "Generator: mmap greska : %s\n", strerror(errno));
        exit(1);
    }

    if (memPtr->last_id < 1) {
        memPtr->last_id = 1;
        pthread_mutex_init(&memPtr->obj, NULL);
    }

    pthread_mutex_lock(&memPtr->obj);

    id = memPtr->last_id;
    memPtr->last_id += J;
    pthread_mutex_unlock(&memPtr->obj);
    close(fd);
    munmap(memPtr, sizeof(mmessage_id));
    return id;
}